import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { collaborationService } from "@/lib/collaboration/websocket";

interface CollaborativeUser {
  id: string;
  name: string;
  color: string;
  cursor?: number;
  isActive: boolean;
}

interface CollaborationPanelProps {
  fileId: string | null;
  onShare: (shareLink: string) => void;
}

export function CollaborationPanel({ fileId, onShare }: CollaborationPanelProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [users, setUsers] = useState<CollaborativeUser[]>([]);
  const [shareLink, setShareLink] = useState("");
  const [isInSession, setIsInSession] = useState(false);

  useEffect(() => {
    // Setup collaboration service listeners
    collaborationService.on('connected', () => {
      setIsConnected(true);
    });

    collaborationService.on('disconnected', () => {
      setIsConnected(false);
      setIsInSession(false);
    });

    collaborationService.on('session-joined', (data: any) => {
      setIsInSession(true);
    });

    collaborationService.on('user-joined', (data: any) => {
      const newUser: CollaborativeUser = {
        id: data.userId,
        name: `User ${data.userId.slice(-4)}`,
        color: generateUserColor(data.userId),
        isActive: true,
      };
      setUsers(prev => [...prev.filter(u => u.id !== data.userId), newUser]);
    });

    collaborationService.on('user-left', (data: any) => {
      setUsers(prev => prev.filter(u => u.id !== data.userId));
    });

    collaborationService.on('cursor-update', (data: any) => {
      setUsers(prev => prev.map(u => 
        u.id === data.userId 
          ? { ...u, cursor: data.position, isActive: true }
          : u
      ));
    });

    return () => {
      collaborationService.off('connected', () => {});
      collaborationService.off('disconnected', () => {});
      collaborationService.off('session-joined', () => {});
      collaborationService.off('user-joined', () => {});
      collaborationService.off('user-left', () => {});
      collaborationService.off('cursor-update', () => {});
    };
  }, []);

  const generateUserColor = (userId: string): string => {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
    const hash = userId.split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    return colors[Math.abs(hash) % colors.length];
  };

  const joinSession = () => {
    if (fileId && isConnected) {
      collaborationService.joinSession(fileId);
    }
  };

  const leaveSession = () => {
    collaborationService.leaveSession();
    setIsInSession(false);
    setUsers([]);
  };

  const generateShareLink = () => {
    if (fileId) {
      const link = `${window.location.origin}?file=${fileId}&collaborate=true`;
      setShareLink(link);
      onShare(link);
      
      // Copy to clipboard
      navigator.clipboard.writeText(link);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Live Collaboration
          </h2>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className="text-xs text-muted-foreground">
              {isConnected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          
          {/* Connection Status */}
          {!isConnected && (
            <div className="text-center text-muted-foreground">
              <i className="fas fa-exclamation-triangle text-yellow-500 text-2xl mb-2"></i>
              <div>Collaboration server unavailable</div>
              <div className="text-xs mt-1">Real-time features disabled</div>
            </div>
          )}

          {/* Session Controls */}
          {isConnected && fileId && (
            <div className="space-y-3">
              {!isInSession ? (
                <Button 
                  onClick={joinSession}
                  className="w-full"
                  data-testid="button-join-session"
                >
                  <i className="fas fa-users mr-2"></i>
                  Start Collaboration
                </Button>
              ) : (
                <Button 
                  onClick={leaveSession}
                  variant="destructive"
                  className="w-full"
                  data-testid="button-leave-session"
                >
                  <i className="fas fa-sign-out-alt mr-2"></i>
                  Leave Session
                </Button>
              )}

              <Button 
                onClick={generateShareLink}
                variant="secondary"
                className="w-full"
                data-testid="button-generate-share"
              >
                <i className="fas fa-share mr-2"></i>
                Generate Share Link
              </Button>

              {shareLink && (
                <div className="bg-muted p-3 rounded text-xs">
                  <div className="text-muted-foreground mb-1">Share Link (copied to clipboard):</div>
                  <div className="break-all text-primary">{shareLink}</div>
                </div>
              )}
            </div>
          )}

          {/* Active Users */}
          {isInSession && users.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Active Collaborators ({users.length})</h3>
              {users.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center space-x-3 p-2 bg-muted rounded"
                  data-testid={`user-${user.id}`}
                >
                  <div 
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: user.color }}
                  ></div>
                  <div className="flex-1">
                    <div className="text-sm font-medium">{user.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {user.cursor !== undefined ? `Line ${Math.floor(user.cursor / 50) + 1}` : 'Idle'}
                    </div>
                  </div>
                  <Badge variant={user.isActive ? "default" : "secondary"}>
                    {user.isActive ? "Active" : "Away"}
                  </Badge>
                </div>
              ))}
            </div>
          )}

          {/* Collaboration Tips */}
          <div className="bg-card p-3 rounded border border-border">
            <h4 className="text-sm font-medium mb-2">💡 Collaboration Tips</h4>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Changes sync in real-time with other users</li>
              <li>• See collaborator cursors while editing</li>
              <li>• Math work updates live for everyone</li>
              <li>• Share links work for 24 hours</li>
            </ul>
          </div>

        </div>
      </ScrollArea>
    </div>
  );
}