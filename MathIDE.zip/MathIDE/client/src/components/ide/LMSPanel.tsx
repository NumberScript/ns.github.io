import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { canvasService } from "@/lib/lms/canvas";
import { googleClassroomService } from "@/lib/lms/googleClassroom";

interface LMSPanelProps {
  onClose: () => void;
}

interface Course {
  id: string | number;
  name: string;
  code?: string;
}

interface Assignment {
  id: string | number;
  title: string;
  description: string;
  dueDate?: string;
  points?: number;
}

export function LMSPanel({ onClose }: LMSPanelProps) {
  const [activeTab, setActiveTab] = useState("canvas");
  
  // Canvas state
  const [canvasConfigured, setCanvasConfigured] = useState(false);
  const [canvasBaseUrl, setCanvasBaseUrl] = useState("");
  const [canvasAccessToken, setCanvasAccessToken] = useState("");
  const [canvasCourses, setCanvasCourses] = useState<Course[]>([]);
  
  // Google Classroom state
  const [classroomConfigured, setClassroomConfigured] = useState(false);
  const [classroomCourses, setClassroomCourses] = useState<Course[]>([]);
  
  // Assignment creation
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [assignmentTitle, setAssignmentTitle] = useState("");
  const [assignmentDescription, setAssignmentDescription] = useState("");
  const [assignmentPoints, setAssignmentPoints] = useState(100);
  const [assignmentDueDate, setAssignmentDueDate] = useState("");

  useEffect(() => {
    setCanvasConfigured(canvasService.isConfigured());
    setClassroomConfigured(googleClassroomService.isConfigured());
  }, []);

  // Canvas Functions
  const configureCanvas = async () => {
    try {
      canvasService.setConfig(canvasBaseUrl, canvasAccessToken);
      setCanvasConfigured(true);
      await loadCanvasCourses();
    } catch (error) {
      console.error("Failed to configure Canvas:", error);
    }
  };

  const loadCanvasCourses = async () => {
    try {
      const courses = await canvasService.getCourses();
      setCanvasCourses(courses.map(c => ({
        id: c.id,
        name: c.name,
        code: c.course_code
      })));
    } catch (error) {
      console.error("Failed to load Canvas courses:", error);
    }
  };

  const createCanvasAssignment = async () => {
    if (!selectedCourse || !assignmentTitle) return;
    
    try {
      const dueDate = assignmentDueDate ? new Date(assignmentDueDate) : undefined;
      await canvasService.createNumberScriptAssignment(
        Number(selectedCourse.id),
        assignmentTitle,
        assignmentDescription,
        dueDate,
        assignmentPoints
      );
      
      // Reset form
      setAssignmentTitle("");
      setAssignmentDescription("");
      setAssignmentPoints(100);
      setAssignmentDueDate("");
      setSelectedCourse(null);
      
      alert("Assignment created successfully!");
    } catch (error) {
      console.error("Failed to create assignment:", error);
      alert("Failed to create assignment. Please check your configuration.");
    }
  };

  // Google Classroom Functions
  const configureClassroom = async () => {
    try {
      // This would typically involve OAuth flow
      // For now, we'll assume the user has already authenticated
      const token = prompt("Enter your Google Classroom access token:");
      if (token) {
        googleClassroomService.setConfig(token);
        setClassroomConfigured(true);
        await loadClassroomCourses();
      }
    } catch (error) {
      console.error("Failed to configure Google Classroom:", error);
    }
  };

  const loadClassroomCourses = async () => {
    try {
      const courses = await googleClassroomService.getCourses();
      setClassroomCourses(courses.map(c => ({
        id: c.id,
        name: c.name,
        code: c.section || ''
      })));
    } catch (error) {
      console.error("Failed to load Classroom courses:", error);
    }
  };

  const createClassroomAssignment = async () => {
    if (!selectedCourse || !assignmentTitle) return;
    
    try {
      const dueDate = assignmentDueDate ? new Date(assignmentDueDate) : undefined;
      await googleClassroomService.createNumberScriptAssignment(
        String(selectedCourse.id),
        assignmentTitle,
        assignmentDescription,
        dueDate,
        assignmentPoints
      );
      
      // Reset form
      setAssignmentTitle("");
      setAssignmentDescription("");
      setAssignmentPoints(100);
      setAssignmentDueDate("");
      setSelectedCourse(null);
      
      alert("Assignment created successfully!");
    } catch (error) {
      console.error("Failed to create assignment:", error);
      alert("Failed to create assignment. Please check your configuration.");
    }
  };

  const renderCanvasPanel = () => (
    <div className="space-y-4">
      {!canvasConfigured ? (
        <div className="space-y-3">
          <div className="text-center text-muted-foreground mb-4">
            <i className="fas fa-graduation-cap text-2xl mb-2"></i>
            <div>Configure Canvas LMS</div>
            <div className="text-xs">Connect to your Canvas instance</div>
          </div>
          
          <div>
            <label className="text-xs font-medium">Canvas Base URL:</label>
            <Input
              value={canvasBaseUrl}
              onChange={(e) => setCanvasBaseUrl(e.target.value)}
              placeholder="https://your-school.instructure.com"
              className="text-sm"
              data-testid="input-canvas-url"
            />
          </div>
          
          <div>
            <label className="text-xs font-medium">Access Token:</label>
            <Input
              type="password"
              value={canvasAccessToken}
              onChange={(e) => setCanvasAccessToken(e.target.value)}
              placeholder="Enter your Canvas API token"
              className="text-sm"
              data-testid="input-canvas-token"
            />
          </div>
          
          <Button 
            onClick={configureCanvas}
            className="w-full"
            data-testid="button-configure-canvas"
          >
            Connect to Canvas
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Badge variant="default">Canvas Connected</Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                canvasService.clearConfig();
                setCanvasConfigured(false);
                setCanvasCourses([]);
              }}
              data-testid="button-disconnect-canvas"
            >
              Disconnect
            </Button>
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-2">Your Courses ({canvasCourses.length})</h3>
            <ScrollArea className="h-32 border rounded">
              {canvasCourses.map((course) => (
                <div
                  key={course.id}
                  className={`p-2 cursor-pointer hover:bg-muted ${
                    selectedCourse?.id === course.id ? 'bg-muted' : ''
                  }`}
                  onClick={() => setSelectedCourse(course)}
                  data-testid={`course-${course.id}`}
                >
                  <div className="text-sm font-medium">{course.name}</div>
                  {course.code && (
                    <div className="text-xs text-muted-foreground">{course.code}</div>
                  )}
                </div>
              ))}
            </ScrollArea>
          </div>
        </div>
      )}
    </div>
  );

  const renderClassroomPanel = () => (
    <div className="space-y-4">
      {!classroomConfigured ? (
        <div className="space-y-3">
          <div className="text-center text-muted-foreground mb-4">
            <i className="fab fa-google text-2xl mb-2"></i>
            <div>Configure Google Classroom</div>
            <div className="text-xs">Connect to Google Classroom</div>
          </div>
          
          <Button 
            onClick={configureClassroom}
            className="w-full bg-blue-600 hover:bg-blue-700"
            data-testid="button-configure-classroom"
          >
            <i className="fab fa-google mr-2"></i>
            Connect to Classroom
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Badge variant="default">Classroom Connected</Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                googleClassroomService.clearConfig();
                setClassroomConfigured(false);
                setClassroomCourses([]);
              }}
              data-testid="button-disconnect-classroom"
            >
              Disconnect
            </Button>
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-2">Your Classes ({classroomCourses.length})</h3>
            <ScrollArea className="h-32 border rounded">
              {classroomCourses.map((course) => (
                <div
                  key={course.id}
                  className={`p-2 cursor-pointer hover:bg-muted ${
                    selectedCourse?.id === course.id ? 'bg-muted' : ''
                  }`}
                  onClick={() => setSelectedCourse(course)}
                  data-testid={`classroom-${course.id}`}
                >
                  <div className="text-sm font-medium">{course.name}</div>
                  {course.code && (
                    <div className="text-xs text-muted-foreground">{course.code}</div>
                  )}
                </div>
              ))}
            </ScrollArea>
          </div>
        </div>
      )}
    </div>
  );

  const renderAssignmentCreator = () => (
    <div className="space-y-3">
      <h3 className="text-sm font-medium">Create NumberScript Assignment</h3>
      
      {selectedCourse && (
        <div className="bg-muted p-2 rounded text-xs">
          Selected: {selectedCourse.name}
        </div>
      )}
      
      <div>
        <label className="text-xs font-medium">Assignment Title:</label>
        <Input
          value={assignmentTitle}
          onChange={(e) => setAssignmentTitle(e.target.value)}
          placeholder="e.g., Calculus Problem Set 1"
          className="text-sm"
          data-testid="input-assignment-title"
        />
      </div>
      
      <div>
        <label className="text-xs font-medium">Description:</label>
        <Textarea
          value={assignmentDescription}
          onChange={(e) => setAssignmentDescription(e.target.value)}
          placeholder="Assignment instructions..."
          className="text-sm h-20"
          data-testid="textarea-assignment-description"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs font-medium">Points:</label>
          <Input
            type="number"
            value={assignmentPoints}
            onChange={(e) => setAssignmentPoints(Number(e.target.value))}
            className="text-sm"
            data-testid="input-assignment-points"
          />
        </div>
        <div>
          <label className="text-xs font-medium">Due Date:</label>
          <Input
            type="datetime-local"
            value={assignmentDueDate}
            onChange={(e) => setAssignmentDueDate(e.target.value)}
            className="text-sm"
            data-testid="input-assignment-due"
          />
        </div>
      </div>
      
      <Button
        onClick={activeTab === "canvas" ? createCanvasAssignment : createClassroomAssignment}
        disabled={!selectedCourse || !assignmentTitle}
        className="w-full"
        data-testid="button-create-assignment"
      >
        Create Assignment
      </Button>
    </div>
  );

  return (
    <div className="w-80 bg-secondary border-l border-border flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            LMS Integration
          </h2>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
            onClick={onClose}
            data-testid="button-close-lms-panel"
          >
            <i className="fas fa-times text-xs"></i>
          </Button>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="m-4 mb-0">
            <TabsTrigger value="canvas" className="flex-1">Canvas</TabsTrigger>
            <TabsTrigger value="classroom" className="flex-1">Classroom</TabsTrigger>
          </TabsList>
          
          <ScrollArea className="flex-1">
            <div className="p-4">
              <TabsContent value="canvas" className="mt-0 space-y-4">
                {renderCanvasPanel()}
                {canvasConfigured && selectedCourse && renderAssignmentCreator()}
              </TabsContent>
              
              <TabsContent value="classroom" className="mt-0 space-y-4">
                {renderClassroomPanel()}
                {classroomConfigured && selectedCourse && renderAssignmentCreator()}
              </TabsContent>
            </div>
          </ScrollArea>
        </Tabs>
      </div>
    </div>
  );
}