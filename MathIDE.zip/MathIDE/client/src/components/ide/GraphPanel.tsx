import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { advancedMath, GraphData } from "@/lib/numberscript/advanced";

interface GraphPanelProps {
  onClose: () => void;
}

export function GraphPanel({ onClose }: GraphPanelProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [expression, setExpression] = useState("sin(x)");
  const [xMin, setXMin] = useState(-10);
  const [xMax, setXMax] = useState(10);
  const [graphs, setGraphs] = useState<GraphData[]>([]);
  const [selectedGraph, setSelectedGraph] = useState<string | null>(null);

  useEffect(() => {
    drawGraphs();
  }, [graphs]);

  const plotFunction = () => {
    try {
      const graphData = advancedMath.plot(expression, xMin, xMax, 0.1);
      setGraphs(prev => [...prev, graphData]);
    } catch (error) {
      console.error("Failed to plot function:", error);
    }
  };

  const clearGraphs = () => {
    setGraphs([]);
    advancedMath.clearGraphs();
    drawGraphs();
  };

  const removeGraph = (index: number) => {
    setGraphs(prev => prev.filter((_, i) => i !== index));
  };

  const drawGraphs = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Set up coordinate system
    const padding = 40;
    const width = canvas.width - 2 * padding;
    const height = canvas.height - 2 * padding;
    
    // Draw grid
    ctx.strokeStyle = '#333333';
    ctx.lineWidth = 1;
    
    // Vertical grid lines
    for (let i = 0; i <= 10; i++) {
      const x = padding + (i / 10) * width;
      ctx.beginPath();
      ctx.moveTo(x, padding);
      ctx.lineTo(x, padding + height);
      ctx.stroke();
    }
    
    // Horizontal grid lines
    for (let i = 0; i <= 10; i++) {
      const y = padding + (i / 10) * height;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(padding + width, y);
      ctx.stroke();
    }
    
    // Draw axes
    ctx.strokeStyle = '#555555';
    ctx.lineWidth = 2;
    
    // X-axis
    const zeroY = padding + height / 2;
    ctx.beginPath();
    ctx.moveTo(padding, zeroY);
    ctx.lineTo(padding + width, zeroY);
    ctx.stroke();
    
    // Y-axis
    const zeroX = padding + width / 2;
    ctx.beginPath();
    ctx.moveTo(zeroX, padding);
    ctx.lineTo(zeroX, padding + height);
    ctx.stroke();
    
    // Draw graphs
    graphs.forEach((graph, index) => {
      if (graph.data.length === 0) return;
      
      ctx.strokeStyle = graph.color;
      ctx.lineWidth = 2;
      
      // Find data bounds
      const xData = graph.data.map(p => p.x);
      const yData = graph.data.map(p => p.y);
      const xMinData = Math.min(...xData);
      const xMaxData = Math.max(...xData);
      const yMinData = Math.min(...yData);
      const yMaxData = Math.max(...yData);
      
      // Scale data to canvas
      const scaleX = width / (xMaxData - xMinData);
      const scaleY = height / (yMaxData - yMinData);
      
      ctx.beginPath();
      graph.data.forEach((point, i) => {
        const x = padding + ((point.x - xMinData) * scaleX);
        const y = padding + height - ((point.y - yMinData) * scaleY);
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();
      
      // Draw points for scatter plots
      if (graph.type === 'scatter') {
        ctx.fillStyle = graph.color;
        graph.data.forEach(point => {
          const x = padding + ((point.x - xMinData) * scaleX);
          const y = padding + height - ((point.y - yMinData) * scaleY);
          ctx.beginPath();
          ctx.arc(x, y, 3, 0, 2 * Math.PI);
          ctx.fill();
        });
      }
    });
    
    // Draw labels
    ctx.fillStyle = '#ffffff';
    ctx.font = '12px monospace';
    ctx.textAlign = 'center';
    
    // X-axis labels
    for (let i = 0; i <= 10; i++) {
      const x = padding + (i / 10) * width;
      const value = xMin + (i / 10) * (xMax - xMin);
      ctx.fillText(value.toFixed(1), x, canvas.height - 10);
    }
    
    // Y-axis labels
    ctx.textAlign = 'right';
    for (let i = 0; i <= 10; i++) {
      const y = padding + (i / 10) * height;
      const value = 10 - (i / 10) * 20; // Simple range -10 to 10
      ctx.fillText(value.toFixed(1), padding - 10, y + 4);
    }
  };

  const predefinedFunctions = [
    "sin(x)", "cos(x)", "tan(x)", "x^2", "x^3", "sqrt(x)", "ln(x)", "e^x"
  ];

  return (
    <div className="w-96 bg-secondary border-l border-border flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Mathematical Graphing
          </h2>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
            onClick={onClose}
            data-testid="button-close-graph-panel"
          >
            <i className="fas fa-times text-xs"></i>
          </Button>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        
        {/* Graph Canvas */}
        <div className="p-4 bg-background">
          <canvas
            ref={canvasRef}
            width={320}
            height={240}
            className="border border-border rounded bg-black"
            data-testid="graph-canvas"
          />
        </div>

        {/* Controls */}
        <div className="p-4 border-b border-border space-y-3">
          <div className="space-y-2">
            <label className="text-xs font-medium">Function f(x):</label>
            <Input
              value={expression}
              onChange={(e) => setExpression(e.target.value)}
              placeholder="Enter function (e.g., sin(x), x^2)"
              className="text-sm"
              data-testid="input-function"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-medium">X Min:</label>
              <Input
                type="number"
                value={xMin}
                onChange={(e) => setXMin(Number(e.target.value))}
                className="text-sm"
                data-testid="input-x-min"
              />
            </div>
            <div>
              <label className="text-xs font-medium">X Max:</label>
              <Input
                type="number"
                value={xMax}
                onChange={(e) => setXMax(Number(e.target.value))}
                className="text-sm"
                data-testid="input-x-max"
              />
            </div>
          </div>

          <div className="flex space-x-2">
            <Button
              onClick={plotFunction}
              className="flex-1"
              data-testid="button-plot"
            >
              <i className="fas fa-chart-line mr-2"></i>
              Plot
            </Button>
            <Button
              onClick={clearGraphs}
              variant="outline"
              className="flex-1"
              data-testid="button-clear"
            >
              <i className="fas fa-eraser mr-2"></i>
              Clear
            </Button>
          </div>
        </div>

        {/* Quick Functions */}
        <div className="p-4 border-b border-border">
          <h3 className="text-xs font-medium mb-2">Quick Functions:</h3>
          <div className="grid grid-cols-2 gap-1">
            {predefinedFunctions.map((func) => (
              <Button
                key={func}
                variant="ghost"
                size="sm"
                className="text-xs h-8"
                onClick={() => setExpression(func)}
                data-testid={`function-${func.replace(/[()^]/g, '')}`}
              >
                {func}
              </Button>
            ))}
          </div>
        </div>

        {/* Graph List */}
        <ScrollArea className="flex-1">
          <div className="p-4">
            <h3 className="text-xs font-medium mb-2">Plotted Functions ({graphs.length}):</h3>
            {graphs.length === 0 ? (
              <div className="text-xs text-muted-foreground text-center py-4">
                No functions plotted yet
              </div>
            ) : (
              <div className="space-y-2">
                {graphs.map((graph, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded border ${
                      selectedGraph === graph.label ? 'border-primary' : 'border-border'
                    } flex items-center justify-between`}
                    onClick={() => setSelectedGraph(graph.label)}
                    data-testid={`graph-item-${index}`}
                  >
                    <div className="flex items-center space-x-2">
                      <div
                        className="w-3 h-3 rounded"
                        style={{ backgroundColor: graph.color }}
                      ></div>
                      <span className="text-xs font-mono">{graph.label}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Badge variant="secondary" className="text-xs">
                        {graph.data.length} pts
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 text-muted-foreground hover:text-red-400"
                        onClick={(e) => {
                          e.stopPropagation();
                          removeGraph(index);
                        }}
                        data-testid={`remove-graph-${index}`}
                      >
                        <i className="fas fa-trash text-xs"></i>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>

      </div>
    </div>
  );
}