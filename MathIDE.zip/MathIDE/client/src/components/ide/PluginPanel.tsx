import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { pluginManager, NumberScriptPlugin, PluginFunction } from "@/lib/plugins/manager";

interface PluginPanelProps {
  onClose: () => void;
}

export function PluginPanel({ onClose }: PluginPanelProps) {
  const [plugins, setPlugins] = useState<NumberScriptPlugin[]>([]);
  const [functions, setFunctions] = useState<Map<string, PluginFunction>>(new Map());
  const [selectedPlugin, setSelectedPlugin] = useState<NumberScriptPlugin | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("installed");

  useEffect(() => {
    loadPlugins();
    loadFunctions();
  }, []);

  const loadPlugins = () => {
    setPlugins(pluginManager.getPlugins());
  };

  const loadFunctions = () => {
    setFunctions(pluginManager.getAllFunctions());
  };

  const togglePlugin = (pluginId: string) => {
    try {
      if (pluginManager.isPluginEnabled(pluginId)) {
        pluginManager.disablePlugin(pluginId);
      } else {
        pluginManager.enablePlugin(pluginId);
      }
      loadPlugins();
      loadFunctions();
    } catch (error) {
      alert(`Failed to toggle plugin: ${error}`);
    }
  };

  const filteredPlugins = plugins.filter(plugin =>
    plugin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    plugin.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredFunctions = Array.from(functions.entries()).filter(([name, func]) =>
    name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    func.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const functionsByCategory = Array.from(functions.values()).reduce((acc, func) => {
    if (!acc[func.category]) {
      acc[func.category] = [];
    }
    acc[func.category].push(func);
    return acc;
  }, {} as Record<string, PluginFunction[]>);

  const categoryIcons: Record<string, string> = {
    'arithmetic': 'calculator',
    'trigonometry': 'wave-square',
    'calculus': 'chart-line',
    'statistics': 'chart-bar',
    'linear-algebra': 'th',
    'utility': 'tools',
    'custom': 'puzzle-piece'
  };

  const renderInstalledPlugins = () => (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Input
          placeholder="Search plugins..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="text-sm"
          data-testid="input-search-plugins"
        />
      </div>

      <div className="space-y-2">
        {filteredPlugins.map((plugin) => (
          <div
            key={plugin.id}
            className="p-3 border border-border rounded hover:bg-muted cursor-pointer"
            onClick={() => setSelectedPlugin(selectedPlugin?.id === plugin.id ? null : plugin)}
            data-testid={`plugin-${plugin.id}`}
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <h3 className="text-sm font-medium">{plugin.name}</h3>
                  <Badge variant="secondary" className="text-xs">
                    v{plugin.version}
                  </Badge>
                  {pluginManager.isPluginEnabled(plugin.id) && (
                    <Badge variant="default" className="text-xs">
                      Enabled
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">{plugin.description}</p>
                <p className="text-xs text-muted-foreground">
                  by {plugin.author} • {plugin.functions.length} functions
                </p>
              </div>
              <Switch
                checked={pluginManager.isPluginEnabled(plugin.id)}
                onCheckedChange={() => togglePlugin(plugin.id)}
                data-testid={`toggle-plugin-${plugin.id}`}
              />
            </div>

            {selectedPlugin?.id === plugin.id && (
              <div className="mt-3 pt-3 border-t border-border">
                <h4 className="text-xs font-medium mb-2">Functions:</h4>
                <div className="space-y-1">
                  {plugin.functions.map((func) => (
                    <div
                      key={func.name}
                      className="text-xs bg-muted p-2 rounded"
                      data-testid={`function-${func.name}`}
                    >
                      <div className="font-mono text-primary">{func.name}</div>
                      <div className="text-muted-foreground">{func.description}</div>
                      <div className="text-muted-foreground">
                        Returns: {func.returnType} • Category: {func.category}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}

        {filteredPlugins.length === 0 && (
          <div className="text-center text-muted-foreground py-8">
            <i className="fas fa-search text-2xl mb-2"></i>
            <div>No plugins found</div>
            <div className="text-xs">Try adjusting your search terms</div>
          </div>
        )}
      </div>
    </div>
  );

  const renderFunctionLibrary = () => (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Input
          placeholder="Search functions..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="text-sm"
          data-testid="input-search-functions"
        />
      </div>

      <div className="text-xs text-muted-foreground">
        {functions.size} functions available across {Object.keys(functionsByCategory).length} categories
      </div>

      {Object.entries(functionsByCategory).map(([category, categoryFunctions]) => (
        <div key={category} className="space-y-2">
          <div className="flex items-center space-x-2">
            <i className={`fas fa-${categoryIcons[category] || 'function'} text-primary`}></i>
            <h3 className="text-sm font-medium capitalize">{category.replace('-', ' ')}</h3>
            <Badge variant="outline" className="text-xs">
              {categoryFunctions.length}
            </Badge>
          </div>

          <div className="grid grid-cols-1 gap-1">
            {categoryFunctions
              .filter(func => 
                searchTerm === "" || 
                func.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                func.description.toLowerCase().includes(searchTerm.toLowerCase())
              )
              .map((func) => (
                <div
                  key={func.name}
                  className="p-2 bg-muted rounded text-xs hover:bg-accent hover:text-accent-foreground cursor-pointer"
                  data-testid={`library-function-${func.name}`}
                >
                  <div className="font-mono text-primary">{func.name}()</div>
                  <div className="text-muted-foreground">{func.description}</div>
                  <div className="text-muted-foreground">
                    Parameters: {func.parameters.length} • Returns: {func.returnType}
                  </div>
                </div>
              ))}
          </div>
        </div>
      ))}

      {filteredFunctions.length === 0 && (
        <div className="text-center text-muted-foreground py-8">
          <i className="fas fa-search text-2xl mb-2"></i>
          <div>No functions found</div>
          <div className="text-xs">Try adjusting your search terms</div>
        </div>
      )}
    </div>
  );

  const renderPluginStore = () => (
    <div className="space-y-4">
      <div className="text-center text-muted-foreground py-8">
        <i className="fas fa-store text-2xl mb-2"></i>
        <div>Plugin Store</div>
        <div className="text-xs">Coming Soon</div>
        <div className="text-xs mt-2">
          Browse and install community-created mathematical plugins
        </div>
      </div>

      <div className="space-y-2">
        <div className="p-3 border border-dashed border-border rounded text-center">
          <h3 className="text-sm font-medium mb-1">Create Custom Plugin</h3>
          <p className="text-xs text-muted-foreground mb-2">
            Build your own mathematical functions and share them
          </p>
          <Button variant="outline" size="sm" disabled>
            Plugin Creator (Coming Soon)
          </Button>
        </div>

        <div className="p-3 border border-dashed border-border rounded text-center">
          <h3 className="text-sm font-medium mb-1">Import Plugin</h3>
          <p className="text-xs text-muted-foreground mb-2">
            Load a plugin from a .js file
          </p>
          <Button variant="outline" size="sm" disabled>
            Import from File (Coming Soon)
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="w-80 bg-secondary border-l border-border flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Plugin Manager
          </h2>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
            onClick={onClose}
            data-testid="button-close-plugin-panel"
          >
            <i className="fas fa-times text-xs"></i>
          </Button>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="m-4 mb-0">
            <TabsTrigger value="installed" className="flex-1 text-xs">Installed</TabsTrigger>
            <TabsTrigger value="functions" className="flex-1 text-xs">Functions</TabsTrigger>
            <TabsTrigger value="store" className="flex-1 text-xs">Store</TabsTrigger>
          </TabsList>
          
          <ScrollArea className="flex-1">
            <div className="p-4">
              <TabsContent value="installed" className="mt-0">
                {renderInstalledPlugins()}
              </TabsContent>
              
              <TabsContent value="functions" className="mt-0">
                {renderFunctionLibrary()}
              </TabsContent>
              
              <TabsContent value="store" className="mt-0">
                {renderPluginStore()}
              </TabsContent>
            </div>
          </ScrollArea>
        </Tabs>
      </div>
    </div>
  );
}