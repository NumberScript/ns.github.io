import { useEffect, useRef } from "react";
import { NumberScriptSyntax } from "@/lib/numberscript/syntax";
import { NumberScriptEvaluator } from "@/lib/numberscript/evaluator";

interface CodeEditorProps {
  file: {
    id: string;
    name: string;
    content: string;
    path: string;
    variables?: Record<string, any>;
  } | null;
  showWork: boolean;
  onContentChange: (content: string) => void;
  onOutput: (output: string) => void;
}

export function CodeEditor({
  file,
  showWork,
  onContentChange,
  onOutput,
}: CodeEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const evaluator = new NumberScriptEvaluator();

  useEffect(() => {
    if (file && textareaRef.current) {
      textareaRef.current.value = file.content;
    }
  }, [file]);

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const content = e.target.value;
    onContentChange(content);
    
    // Real-time evaluation for NumberScript
    if (showWork) {
      try {
        const result = evaluator.evaluateWithSteps(content);
        if (result.output) {
          onOutput(result.output);
        }
      } catch (error) {
        console.error("Evaluation error:", error);
      }
    }
  };

  const renderLineNumbers = () => {
    const content = file?.content || "";
    const lines = content.split("\n");
    return (
      <div className="w-12 bg-secondary border-r border-border text-muted-foreground text-center text-xs py-4 select-none">
        <div className="space-y-0">
          {lines.map((_, index) => (
            <div
              key={index + 1}
              className="h-5 leading-5"
              data-testid={`line-number-${index + 1}`}
            >
              {index + 1}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderSyntaxHighlightedContent = () => {
    const content = file?.content || "";
    const highlightedContent = NumberScriptSyntax.highlight(content);
    
    return (
      <div
        className="flex-1 p-4 overflow-auto font-mono text-sm relative"
        style={{ lineHeight: "1.4" }}
      >
        <div
          className="absolute inset-4 pointer-events-none whitespace-pre-wrap break-words"
          dangerouslySetInnerHTML={{ __html: highlightedContent }}
        />
        <textarea
          ref={textareaRef}
          className="w-full h-full bg-transparent text-transparent caret-white resize-none outline-none font-mono text-sm"
          style={{ 
            lineHeight: "1.4",
            fontSize: "14px",
            fontFamily: "var(--font-mono)"
          }}
          onChange={handleContentChange}
          spellCheck={false}
          autoComplete="off"
          data-testid="code-textarea"
        />
      </div>
    );
  };

  if (!file) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <i className="fas fa-file-code text-4xl mb-4 opacity-50"></i>
          <div>No file selected</div>
          <div className="text-xs mt-1">Open a file or create a new one to start coding</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 relative bg-background" ref={editorRef}>
      <div className="absolute inset-0 flex">
        {renderLineNumbers()}
        {renderSyntaxHighlightedContent()}
      </div>
    </div>
  );
}
