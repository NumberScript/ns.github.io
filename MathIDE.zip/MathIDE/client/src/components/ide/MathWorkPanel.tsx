import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";

interface MathStep {
  title: string;
  steps: string[];
  result: string;
  status: "complete" | "in-progress" | "pending";
}

interface MathWorkPanelProps {
  steps: MathStep[];
  variables: Record<string, any>;
  onClose: () => void;
}

export function MathWorkPanel({ steps, variables, onClose }: MathWorkPanelProps) {
  return (
    <div className="w-96 bg-secondary border-l border-border flex flex-col">
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Mathematical Work
          </h2>
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-xs text-muted-foreground">Live</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
              onClick={onClose}
              data-testid="button-close-math-panel"
            >
              <i className="fas fa-times text-xs"></i>
            </Button>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          
          {/* Mathematical Steps */}
          {steps.map((step, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg ${
                step.status === "in-progress"
                  ? "bg-primary/10 border border-primary/30"
                  : "bg-muted/50"
              }`}
              data-testid={`math-step-${index}`}
            >
              <div className="text-sm font-medium text-primary mb-3 flex items-center">
                {step.status === "in-progress" && (
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse mr-2"></div>
                )}
                {step.title}
              </div>
              <div className="space-y-2 text-sm math-expression">
                {step.steps.map((stepText, stepIndex) => (
                  <div key={stepIndex} className={stepIndex === 0 ? "text-muted-foreground" : ""}>
                    {stepText}
                  </div>
                ))}
                {step.status === "complete" && (
                  <div className="text-primary font-medium">= {step.result}</div>
                )}
                {step.status === "in-progress" && (
                  <div className="text-primary animate-pulse">Calculating...</div>
                )}
              </div>
              
              {step.status === "complete" && (
                <div className="mt-3 text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded">
                  <i className="fas fa-check mr-1"></i>
                  Calculation complete
                </div>
              )}
            </div>
          ))}

          {/* Variables Panel */}
          <div className="bg-card p-4 rounded-lg border border-border">
            <div className="text-sm font-medium mb-3">Variables</div>
            <div className="space-y-2 text-sm">
              {Object.entries(variables).map(([name, value]) => (
                <div key={name} className="flex justify-between" data-testid={`variable-${name}`}>
                  <span className="text-muted-foreground">{name}:</span>
                  <span className="font-mono text-primary">{String(value)}</span>
                </div>
              ))}
              {Object.keys(variables).length === 0 && (
                <div className="text-muted-foreground text-xs">No variables defined</div>
              )}
            </div>
          </div>

        </div>
      </ScrollArea>
    </div>
  );
}
