import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface ActivityBarProps {
  activePanel: string;
  setActivePanel: (panel: string) => void;
}

export function ActivityBar({ activePanel, setActivePanel }: ActivityBarProps) {
  const panels = [
    { id: "explorer", icon: "folder-open", tooltip: "Explorer" },
    { id: "search", icon: "search", tooltip: "Search" },
    { id: "math", icon: "calculator", tooltip: "Mathematical Functions" },
    { id: "collaboration", icon: "users", tooltip: "Live Collaboration" },
    { id: "cloud", icon: "cloud", tooltip: "Cloud Storage" },
    { id: "graph", icon: "chart-line", tooltip: "Mathematical Graphing" },
    { id: "lms", icon: "graduation-cap", tooltip: "LMS Integration" },
    { id: "plugins", icon: "puzzle-piece", tooltip: "Plugin Manager" },
  ];

  const bottomPanels = [
    { id: "settings", icon: "cog", tooltip: "Settings" },
  ];

  return (
    <div className="w-12 bg-card border-r border-border flex flex-col items-center py-2 space-y-1">
      {panels.map((panel) => (
        <Tooltip key={panel.id}>
          <TooltipTrigger asChild>
            <button
              className={`activity-bar-icon w-10 h-10 rounded-md flex items-center justify-center text-sm hover:bg-muted transition-colors ${
                activePanel === panel.id ? "active bg-primary text-primary-foreground" : ""
              }`}
              onClick={() => setActivePanel(panel.id)}
              data-testid={`activity-${panel.id}`}
            >
              <i className={`fas fa-${panel.icon}`}></i>
            </button>
          </TooltipTrigger>
          <TooltipContent side="right">
            {panel.tooltip}
          </TooltipContent>
        </Tooltip>
      ))}
      
      <div className="flex-1"></div>
      
      {bottomPanels.map((panel) => (
        <Tooltip key={panel.id}>
          <TooltipTrigger asChild>
            <button
              className={`activity-bar-icon w-10 h-10 rounded-md flex items-center justify-center text-sm hover:bg-muted transition-colors ${
                activePanel === panel.id ? "active bg-primary text-primary-foreground" : ""
              }`}
              onClick={() => setActivePanel(panel.id)}
              data-testid={`activity-${panel.id}`}
            >
              <i className={`fas fa-${panel.icon}`}></i>
            </button>
          </TooltipTrigger>
          <TooltipContent side="right">
            {panel.tooltip}
          </TooltipContent>
        </Tooltip>
      ))}
    </div>
  );
}
