import { Switch } from "@/components/ui/switch";

interface TabBarProps {
  openFiles: Array<{
    id: string;
    name: string;
    content: string;
    path: string;
  }>;
  activeFile: any;
  setActiveFile: (file: any) => void;
  closeFile: (fileId: string) => void;
  showWork: boolean;
  setShowWork: (show: boolean) => void;
}

export function TabBar({
  openFiles,
  activeFile,
  setActiveFile,
  closeFile,
  showWork,
  setShowWork,
}: TabBarProps) {
  return (
    <div className="bg-card border-b border-border flex items-center">
      <div className="flex">
        {openFiles.map((file) => (
          <div
            key={file.id}
            className={`flex items-center px-4 py-2 text-sm cursor-pointer relative border-r border-border ${
              activeFile?.id === file.id
                ? "bg-background text-foreground"
                : "text-muted-foreground hover:text-foreground hover:bg-muted"
            }`}
            onClick={() => setActiveFile(file)}
            data-testid={`tab-${file.id}`}
          >
            <i className="fas fa-file-code text-primary mr-2 text-xs"></i>
            <span>{file.name}</span>
            <button
              className="ml-2 text-muted-foreground hover:text-foreground"
              onClick={(e) => {
                e.stopPropagation();
                closeFile(file.id);
              }}
              data-testid={`tab-close-${file.id}`}
            >
              <i className="fas fa-times text-xs"></i>
            </button>
            {activeFile?.id === file.id && (
              <div className="absolute top-0 left-0 w-full h-0.5 bg-primary"></div>
            )}
          </div>
        ))}
      </div>
      
      <div className="flex-1"></div>
      
      <div className="flex items-center px-4 py-2 space-x-3">
        <div className="flex items-center space-x-2">
          <span className="text-xs text-muted-foreground">Show Work:</span>
          <Switch
            checked={showWork}
            onCheckedChange={setShowWork}
            data-testid="switch-show-work"
          />
          <span className="text-xs text-primary font-medium">
            {showWork ? "true" : "false"}
          </span>
        </div>
      </div>
    </div>
  );
}
