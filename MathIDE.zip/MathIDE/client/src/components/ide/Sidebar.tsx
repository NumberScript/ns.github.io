import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileSystemService } from "@/lib/storage/fileSystem";
import { GoogleDriveService } from "@/lib/storage/googleDrive";
import { GitHubService } from "@/lib/storage/github";
import { OAuthService } from "@/lib/auth/oauth";
import { CollaborationPanel } from "./CollaborationPanel";
import { GraphPanel } from "./GraphPanel";
import { LMSPanel } from "./LMSPanel";
import { PluginPanel } from "./PluginPanel";

interface SidebarProps {
  activePanel: string;
  openFiles: Array<{
    id: string;
    name: string;
    content: string;
    path: string;
    variables?: Record<string, any>;
  }>;
  activeFile: any;
  setActiveFile: (file: any) => void;
  createNewFile: () => void;
}

export function Sidebar({
  activePanel,
  openFiles,
  activeFile,
  setActiveFile,
  createNewFile,
}: SidebarProps) {
  const fileSystemService = new FileSystemService();
  const googleDriveService = new GoogleDriveService();
  const githubService = new GitHubService();
  const oauthService = new OAuthService();

  const handleSaveLocal = async () => {
    if (activeFile) {
      await fileSystemService.saveFile(activeFile.name, activeFile.content);
    }
  };

  const handleLoadLocal = async () => {
    try {
      const file = await fileSystemService.loadFile();
      if (file) {
        // Add loaded file to open files
        setActiveFile(file);
      }
    } catch (error) {
      console.error("Failed to load file:", error);
    }
  };

  const handleGoogleAuth = async () => {
    try {
      await oauthService.signInWithGoogle();
    } catch (error) {
      console.error("Google auth failed:", error);
    }
  };

  const handleGitHubAuth = async () => {
    try {
      await oauthService.signInWithGitHub();
    } catch (error) {
      console.error("GitHub auth failed:", error);
    }
  };

  const renderExplorerPanel = () => (
    <div className="flex-1 panel">
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Explorer
          </h2>
          <div className="flex space-x-1">
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
              onClick={createNewFile}
              data-testid="button-new-file"
            >
              <i className="fas fa-file-plus text-xs"></i>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
              onClick={handleLoadLocal}
              data-testid="button-load-file"
            >
              <i className="fas fa-folder-open text-xs"></i>
            </Button>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="px-2 py-1">
          <div className="text-xs font-medium text-muted-foreground mb-2 px-2">
            NUMBERSCRIPT WORKSPACE
          </div>

          <div className="space-y-1">
            {openFiles.map((file) => (
              <div
                key={file.id}
                className={`sidebar-item flex items-center px-2 py-1 text-sm cursor-pointer rounded group ${
                  activeFile?.id === file.id
                    ? "bg-muted border-l-2 border-primary"
                    : "hover:bg-muted"
                }`}
                onClick={() => setActiveFile(file)}
                data-testid={`file-item-${file.id}`}
              >
                <i className="fas fa-file-code text-primary mr-2 text-xs"></i>
                <span>{file.name}</span>
              </div>
            ))}
          </div>

          {openFiles.length === 0 && (
            <div className="px-2 py-4 text-xs text-muted-foreground text-center">
              No files open. Create a new file to get started.
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );

  const renderMathPanel = () => (
    <div className="flex-1 panel">
      <div className="px-4 py-3 border-b border-border">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Mathematical Functions
        </h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-3">
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-primary">Basic Operations</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {["solve", "simplify", "factor", "expand"].map((func) => (
                <div
                  key={func}
                  className="bg-muted p-2 rounded cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors"
                  data-testid={`function-${func}`}
                >
                  {func}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-medium text-primary">Trigonometry</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {["sin", "cos", "tan", "asin", "acos", "atan"].map((func) => (
                <div
                  key={func}
                  className="bg-muted p-2 rounded cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors"
                  data-testid={`function-${func}`}
                >
                  {func}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-medium text-primary">Advanced Functions</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {["factorial", "fibonacci", "gcd", "lcm", "mean", "isPrime"].map((func) => (
                <div
                  key={func}
                  className="bg-muted p-2 rounded cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors"
                  data-testid={`function-${func}`}
                >
                  {func}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-medium text-primary">Calculus & Statistics</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {["derive", "integrate", "plot", "statistics"].map((func) => (
                <div
                  key={func}
                  className="bg-muted p-2 rounded cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors"
                  data-testid={`function-${func}`}
                >
                  {func}
                </div>
              ))}
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );

  const renderCloudPanel = () => (
    <div className="flex-1 panel">
      <div className="px-4 py-3 border-b border-border">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Cloud Storage
        </h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          <div className="text-center text-muted-foreground text-sm mb-4">
            <i className="fas fa-user-circle text-2xl mb-2"></i>
            <div>Guest Mode</div>
            <div className="text-xs">Sign in to access cloud features</div>
          </div>

          <div className="space-y-2">
            <Button
              onClick={handleGoogleAuth}
              className="w-full bg-red-600 text-white hover:bg-red-700"
              data-testid="button-google-auth"
            >
              <i className="fab fa-google mr-2"></i>
              Sign in with Google
            </Button>

            <Button
              onClick={handleGitHubAuth}
              className="w-full bg-gray-800 text-white hover:bg-gray-700"
              data-testid="button-github-auth"
            >
              <i className="fab fa-github mr-2"></i>
              Sign in with GitHub
            </Button>
          </div>

          <div className="border-t border-border pt-4 mt-4">
            <h4 className="text-sm font-medium mb-2">Local Files</h4>
            <Button
              onClick={handleSaveLocal}
              className="w-full"
              variant="secondary"
              data-testid="button-save-local"
            >
              <i className="fas fa-download mr-2"></i>
              Save as .numscript
            </Button>
          </div>
        </div>
      </ScrollArea>
    </div>
  );

  const renderCollaborationPanel = () => (
    <div className="flex-1 panel">
      <div className="px-4 py-3 border-b border-border">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Live Collaboration
        </h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          <div className="text-center text-muted-foreground text-sm mb-4">
            <i className="fas fa-users text-2xl mb-2"></i>
            <div>No active collaborators</div>
            <div className="text-xs">Share your workspace to collaborate</div>
          </div>

          <Button
            className="w-full"
            data-testid="button-share-workspace"
          >
            <i className="fas fa-share mr-2"></i>
            Share Workspace
          </Button>
        </div>
      </ScrollArea>
    </div>
  );

  // Handle new panels that are rendered as separate components
  if (activePanel === "collaboration") {
    return (
      <CollaborationPanel 
        fileId={activeFile?.id || null}
        onShare={(link) => console.log("Share link:", link)}
      />
    );
  }

  if (activePanel === "graph") {
    return <GraphPanel onClose={() => {}} />;
  }

  if (activePanel === "lms") {
    return <LMSPanel onClose={() => {}} />;
  }

  if (activePanel === "plugins") {
    return <PluginPanel onClose={() => {}} />;
  }

  return (
    <div className="w-80 bg-secondary border-r border-border flex flex-col">
      {activePanel === "explorer" && renderExplorerPanel()}
      {activePanel === "math" && renderMathPanel()}
      {activePanel === "cloud" && renderCloudPanel()}
      {activePanel === "search" && (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          Search functionality coming soon
        </div>
      )}
      {activePanel === "settings" && (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          Settings panel coming soon
        </div>
      )}
    </div>
  );
}
