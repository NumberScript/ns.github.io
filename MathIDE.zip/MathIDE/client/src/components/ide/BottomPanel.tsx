import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface BottomPanelProps {
  consoleOutput: Array<{
    type: "input" | "output" | "error" | "info";
    content: string;
    timestamp: Date;
  }>;
  onClose: () => void;
}

export function BottomPanel({ consoleOutput, onClose }: BottomPanelProps) {
  const [activeTab, setActiveTab] = useState("console");

  const tabs = [
    { id: "console", label: "NumberScript Console", icon: "terminal" },
    { id: "problems", label: "Problems", icon: "exclamation-triangle", count: 0 },
    { id: "output", label: "Output", icon: "play-circle" },
  ];

  return (
    <div className="h-64 bg-card border-t border-border flex flex-col">
      
      {/* Panel Tabs */}
      <div className="flex items-center bg-secondary border-b border-border">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            className={`px-4 py-2 text-sm flex items-center ${
              activeTab === tab.id
                ? "bg-background text-foreground border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-muted"
            }`}
            onClick={() => setActiveTab(tab.id)}
            data-testid={`tab-${tab.id}`}
          >
            <i className={`fas fa-${tab.icon} mr-2 text-xs`}></i>
            {tab.label}
            {tab.count !== undefined && ` (${tab.count})`}
          </button>
        ))}
        
        <div className="flex-1"></div>
        
        <Button
          variant="ghost"
          size="sm"
          className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
          onClick={onClose}
          data-testid="button-close-bottom-panel"
        >
          <i className="fas fa-times text-xs"></i>
        </Button>
      </div>

      {/* Panel Content */}
      <ScrollArea className="flex-1">
        <div className="font-mono text-sm p-4 bg-background">
          
          {activeTab === "console" && (
            <div className="space-y-2">
              <div className="text-muted-foreground">
                NumberScript Console v1.0 - Mathematical Computing Environment
              </div>
              <div className="text-muted-foreground">
                Type 'help' for available commands
              </div>
              
              {consoleOutput.map((output, index) => (
                <div
                  key={index}
                  className={`${
                    output.type === "error"
                      ? "text-red-400"
                      : output.type === "output"
                      ? "text-green-400"
                      : output.type === "input"
                      ? "text-primary"
                      : "text-muted-foreground"
                  }`}
                  data-testid={`console-output-${index}`}
                >
                  {output.type === "input" && "> "}
                  {output.content}
                  {output.type === "output" && " ✓"}
                </div>
              ))}
              
              <div className="text-primary">{'>'}</div>
              
              {consoleOutput.length === 0 && (
                <div className="text-muted-foreground mt-4">
                  Console output will appear here when code is executed...
                </div>
              )}
            </div>
          )}

          {activeTab === "problems" && (
            <div className="text-muted-foreground">No problems detected</div>
          )}

          {activeTab === "output" && (
            <div className="text-muted-foreground">
              Program output will appear here when executed...
            </div>
          )}
          
        </div>
      </ScrollArea>
    </div>
  );
}
