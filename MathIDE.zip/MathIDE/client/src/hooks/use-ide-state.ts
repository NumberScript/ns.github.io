import { useState } from "react";
import { NumberScriptEvaluator } from "@/lib/numberscript/evaluator";

interface FileState {
  id: string;
  name: string;
  content: string;
  path: string;
  variables?: Record<string, any>;
}

interface ConsoleOutput {
  type: "input" | "output" | "error" | "info";
  content: string;
  timestamp: Date;
}

interface MathStep {
  title: string;
  steps: string[];
  result: string;
  status: "complete" | "in-progress" | "pending";
}

export function useIDEState() {
  const [activePanel, setActivePanel] = useState("explorer");
  const [openFiles, setOpenFiles] = useState<FileState[]>([]);
  const [activeFile, setActiveFile] = useState<FileState | null>(null);
  const [showWork, setShowWork] = useState(true);
  const [mathWorkSteps, setMathWorkSteps] = useState<MathStep[]>([]);
  const [consoleOutput, setConsoleOutput] = useState<ConsoleOutput[]>([
    {
      type: "info",
      content: "NumberScript Console v1.0 - Mathematical Computing Environment",
      timestamp: new Date(),
    },
    {
      type: "info",
      content: "Type 'help' for available commands",
      timestamp: new Date(),
    },
  ]);

  const evaluator = new NumberScriptEvaluator();

  const addConsoleOutput = (content: string, type: ConsoleOutput["type"] = "output") => {
    setConsoleOutput(prev => [...prev, {
      type,
      content,
      timestamp: new Date(),
    }]);
  };

  const createNewFile = () => {
    const newFile: FileState = {
      id: `file-${Date.now()}`,
      name: `untitled-${openFiles.length + 1}.numscript`,
      content: `// New NumberScript file
// Try: solve 2 + 2

showWork == true

// Example: Solve a simple equation
solve 1 + 1`,
      path: "",
      variables: {},
    };

    setOpenFiles(prev => [...prev, newFile]);
    setActiveFile(newFile);
  };

  const closeFile = (fileId: string) => {
    setOpenFiles(prev => prev.filter(f => f.id !== fileId));
    if (activeFile?.id === fileId) {
      const remaining = openFiles.filter(f => f.id !== fileId);
      setActiveFile(remaining.length > 0 ? remaining[0] : null);
    }
  };

  const updateFileContent = (fileId: string, content: string) => {
    setOpenFiles(prev => prev.map(f => 
      f.id === fileId ? { ...f, content } : f
    ));
    
    if (activeFile?.id === fileId) {
      setActiveFile(prev => prev ? { ...prev, content } : null);
    }

    // Evaluate NumberScript if showWork is enabled
    if (showWork) {
      try {
        const result = evaluator.evaluateWithSteps(content);
        setMathWorkSteps(result.steps);
        
        const file = openFiles.find(f => f.id === fileId);
        if (file) {
          file.variables = result.variables;
        }
      } catch (error) {
        addConsoleOutput(`Error: ${error}`, "error");
      }
    }
  };

  // Initialize with a demo file if no files are open
  if (openFiles.length === 0) {
    createNewFile();
  }

  return {
    activePanel,
    setActivePanel,
    openFiles,
    activeFile,
    setActiveFile,
    showWork,
    setShowWork,
    mathWorkSteps,
    consoleOutput,
    addConsoleOutput,
    createNewFile,
    closeFile,
    updateFileContent,
  };
}
