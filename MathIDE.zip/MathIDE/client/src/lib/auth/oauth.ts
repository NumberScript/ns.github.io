import oauthConfig from "@/config/oauth.json";
import { GoogleDriveService } from "@/lib/storage/googleDrive";
import { GitHubService } from "@/lib/storage/github";

export class OAuthService {
  private googleDriveService = new GoogleDriveService();
  private githubService = new GitHubService();

  async signInWithGoogle(): Promise<void> {
    const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID || oauthConfig.google.clientId;
    
    if (!clientId) {
      throw new Error('Google OAuth not configured');
    }

    const redirectUri = this.getRedirectUri();
    const scope = 'https://www.googleapis.com/auth/drive.file';
    
    const authUrl = new URL('https://accounts.google.com/oauth/authorize');
    authUrl.searchParams.set('client_id', clientId);
    authUrl.searchParams.set('redirect_uri', redirectUri);
    authUrl.searchParams.set('response_type', 'token');
    authUrl.searchParams.set('scope', scope);
    authUrl.searchParams.set('state', 'google-auth');

    // Open popup or redirect
    if (this.isMobile()) {
      window.location.href = authUrl.toString();
    } else {
      this.openAuthPopup(authUrl.toString(), 'google');
    }
  }

  async signInWithGitHub(): Promise<void> {
    const clientId = import.meta.env.VITE_GITHUB_CLIENT_ID || oauthConfig.github.clientId;
    
    if (!clientId) {
      throw new Error('GitHub OAuth not configured');
    }

    const redirectUri = this.getRedirectUri();
    const scope = 'repo,user:email';
    
    const authUrl = new URL('https://github.com/login/oauth/authorize');
    authUrl.searchParams.set('client_id', clientId);
    authUrl.searchParams.set('redirect_uri', redirectUri);
    authUrl.searchParams.set('scope', scope);
    authUrl.searchParams.set('state', 'github-auth');

    // Open popup or redirect
    if (this.isMobile()) {
      window.location.href = authUrl.toString();
    } else {
      this.openAuthPopup(authUrl.toString(), 'github');
    }
  }

  private openAuthPopup(url: string, provider: string): void {
    const popup = window.open(
      url,
      `${provider}-auth`,
      'width=500,height=600,scrollbars=yes,resizable=yes'
    );

    // Listen for popup completion
    const checkClosed = setInterval(() => {
      if (popup?.closed) {
        clearInterval(checkClosed);
        this.handleAuthComplete();
      }
    }, 1000);
  }

  private async handleAuthComplete(): Promise<void> {
    // Check URL fragments for access token (from redirect)
    const urlParams = new URLSearchParams(window.location.hash.substring(1));
    const accessToken = urlParams.get('access_token');
    const state = urlParams.get('state');

    if (accessToken && state) {
      if (state === 'google-auth') {
        this.googleDriveService.setAccessToken(accessToken);
      } else if (state === 'github-auth') {
        this.githubService.setAccessToken(accessToken);
      }
      
      // Clean up URL
      window.location.hash = '';
    }
  }

  private getRedirectUri(): string {
    const domains = process.env.REPLIT_DOMAINS?.split(',') || [];
    const currentDomain = domains[0] || window.location.origin;
    return `${currentDomain}/auth/callback`;
  }

  private isMobile(): boolean {
    return /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  }

  isGoogleAuthenticated(): boolean {
    return this.googleDriveService.isAuthenticated();
  }

  isGitHubAuthenticated(): boolean {
    return this.githubService.isAuthenticated();
  }

  signOut(): void {
    this.googleDriveService.clearAccessToken();
    this.githubService.clearAccessToken();
  }
}
