export class FileSystemService {
  async saveFile(filename: string, content: string): Promise<void> {
    try {
      // Use the File System Access API if available, fall back to download
      if ('showSaveFilePicker' in window) {
        const fileHandle = await (window as any).showSaveFilePicker({
          suggestedName: filename.endsWith('.numscript') ? filename : `${filename}.numscript`,
          types: [{
            description: 'NumberScript files',
            accept: { 'text/plain': ['.numscript'] },
          }],
        });
        
        const writable = await fileHandle.createWritable();
        await writable.write(content);
        await writable.close();
      } else {
        // Fallback: trigger download
        this.downloadFile(filename, content);
      }
    } catch (error) {
      console.error('Save failed:', error);
      // Fallback to download
      this.downloadFile(filename, content);
    }
  }

  async loadFile(): Promise<{ id: string; name: string; content: string; path: string } | null> {
    try {
      if ('showOpenFilePicker' in window) {
        const [fileHandle] = await (window as any).showOpenFilePicker({
          types: [{
            description: 'NumberScript files',
            accept: { 'text/plain': ['.numscript', '.txt'] },
          }],
        });
        
        const file = await fileHandle.getFile();
        const content = await file.text();
        
        return {
          id: `file-${Date.now()}`,
          name: file.name,
          content,
          path: file.name,
        };
      } else {
        // Fallback: use file input
        return this.loadFileWithInput();
      }
    } catch (error) {
      console.error('Load failed:', error);
      return null;
    }
  }

  private downloadFile(filename: string, content: string): void {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename.endsWith('.numscript') ? filename : `${filename}.numscript`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  private async loadFileWithInput(): Promise<{ id: string; name: string; content: string; path: string } | null> {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.numscript,.txt';
      
      input.onchange = async (e) => {
        const file = (e.target as HTMLInputElement).files?.[0];
        if (file) {
          const content = await file.text();
          resolve({
            id: `file-${Date.now()}`,
            name: file.name,
            content,
            path: file.name,
          });
        } else {
          resolve(null);
        }
      };
      
      input.click();
    });
  }

  // Local storage for persistence
  saveToLocalStorage(filename: string, content: string): void {
    const files = this.getLocalFiles();
    files[filename] = content;
    localStorage.setItem('numberscript-files', JSON.stringify(files));
  }

  getLocalFiles(): Record<string, string> {
    const stored = localStorage.getItem('numberscript-files');
    return stored ? JSON.parse(stored) : {};
  }

  deleteFromLocalStorage(filename: string): void {
    const files = this.getLocalFiles();
    delete files[filename];
    localStorage.setItem('numberscript-files', JSON.stringify(files));
  }
}
