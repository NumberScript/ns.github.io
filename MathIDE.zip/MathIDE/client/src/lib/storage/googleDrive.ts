export class GoogleDriveService {
  private accessToken: string | null = null;
  
  constructor() {
    this.accessToken = localStorage.getItem('google-access-token');
  }

  async saveFile(filename: string, content: string, fileId?: string): Promise<string> {
    if (!this.accessToken) {
      throw new Error('Not authenticated with Google Drive');
    }

    const metadata = {
      name: filename.endsWith('.numscript') ? filename : `${filename}.numscript`,
      parents: ['appDataFolder'], // Store in app data folder
    };

    const boundary = '-------314159265358979323846';
    const delimiter = "\r\n--" + boundary + "\r\n";
    const close_delim = "\r\n--" + boundary + "--";

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: text/plain\r\n\r\n' +
      content +
      close_delim;

    const url = fileId
      ? `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=multipart`
      : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';

    const response = await fetch(url, {
      method: fileId ? 'PATCH' : 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': `multipart/related; boundary="${boundary}"`,
      },
      body: multipartRequestBody,
    });

    if (!response.ok) {
      throw new Error('Failed to save file to Google Drive');
    }

    const result = await response.json();
    return result.id;
  }

  async loadFile(fileId: string): Promise<{ name: string; content: string }> {
    if (!this.accessToken) {
      throw new Error('Not authenticated with Google Drive');
    }

    // Get file metadata
    const metadataResponse = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
      },
    });

    if (!metadataResponse.ok) {
      throw new Error('Failed to load file metadata');
    }

    const metadata = await metadataResponse.json();

    // Get file content
    const contentResponse = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
      },
    });

    if (!contentResponse.ok) {
      throw new Error('Failed to load file content');
    }

    const content = await contentResponse.text();

    return {
      name: metadata.name,
      content,
    };
  }

  async listFiles(): Promise<Array<{ id: string; name: string; modifiedTime: string }>> {
    if (!this.accessToken) {
      throw new Error('Not authenticated with Google Drive');
    }

    const response = await fetch(
      "https://www.googleapis.com/drive/v3/files?q=parents in 'appDataFolder'&fields=files(id,name,modifiedTime)",
      {
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error('Failed to list files');
    }

    const result = await response.json();
    return result.files || [];
  }

  setAccessToken(token: string): void {
    this.accessToken = token;
    localStorage.setItem('google-access-token', token);
  }

  clearAccessToken(): void {
    this.accessToken = null;
    localStorage.removeItem('google-access-token');
  }

  isAuthenticated(): boolean {
    return !!this.accessToken;
  }
}
