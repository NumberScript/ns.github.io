interface GitHubFile {
  name: string;
  content: string;
  sha?: string;
}

export class GitHubService {
  private accessToken: string | null = null;
  
  constructor() {
    this.accessToken = localStorage.getItem('github-access-token');
  }

  async createRepository(name: string, isPrivate: boolean = false): Promise<any> {
    if (!this.accessToken) {
      throw new Error('Not authenticated with GitHub');
    }

    const response = await fetch('https://api.github.com/user/repos', {
      method: 'POST',
      headers: {
        'Authorization': `token ${this.accessToken}`,
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name,
        description: 'NumberScript project',
        private: isPrivate,
        auto_init: true,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to create repository');
    }

    return response.json();
  }

  async saveFile(
    repo: string, 
    path: string, 
    content: string, 
    message: string = 'Update NumberScript file',
    sha?: string
  ): Promise<any> {
    if (!this.accessToken) {
      throw new Error('Not authenticated with GitHub');
    }

    const encodedContent = btoa(unescape(encodeURIComponent(content)));

    const body: any = {
      message,
      content: encodedContent,
    };

    if (sha) {
      body.sha = sha;
    }

    const response = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${this.accessToken}`,
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error('Failed to save file to GitHub');
    }

    return response.json();
  }

  async loadFile(repo: string, path: string): Promise<GitHubFile> {
    if (!this.accessToken) {
      throw new Error('Not authenticated with GitHub');
    }

    const response = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
      headers: {
        'Authorization': `token ${this.accessToken}`,
        'Accept': 'application/vnd.github.v3+json',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to load file from GitHub');
    }

    const data = await response.json();
    const content = decodeURIComponent(escape(atob(data.content)));

    return {
      name: data.name,
      content,
      sha: data.sha,
    };
  }

  async listRepositories(): Promise<Array<{ id: number; name: string; full_name: string }>> {
    if (!this.accessToken) {
      throw new Error('Not authenticated with GitHub');
    }

    const response = await fetch('https://api.github.com/user/repos?per_page=100', {
      headers: {
        'Authorization': `token ${this.accessToken}`,
        'Accept': 'application/vnd.github.v3+json',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to list repositories');
    }

    return response.json();
  }

  async getRepositoryContents(repo: string, path: string = ''): Promise<any[]> {
    if (!this.accessToken) {
      throw new Error('Not authenticated with GitHub');
    }

    const response = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
      headers: {
        'Authorization': `token ${this.accessToken}`,
        'Accept': 'application/vnd.github.v3+json',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to get repository contents');
    }

    return response.json();
  }

  setAccessToken(token: string): void {
    this.accessToken = token;
    localStorage.setItem('github-access-token', token);
  }

  clearAccessToken(): void {
    this.accessToken = null;
    localStorage.removeItem('github-access-token');
  }

  isAuthenticated(): boolean {
    return !!this.accessToken;
  }
}
