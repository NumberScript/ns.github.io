interface ClassroomConfig {
  accessToken: string;
}

interface ClassroomCourse {
  id: string;
  name: string;
  section: string;
  description: string;
  room: string;
  ownerId: string;
  creationTime: string;
  updateTime: string;
  enrollmentCode: string;
  courseState: string;
  alternateLink: string;
}

interface ClassroomStudent {
  courseId: string;
  userId: string;
  profile: {
    id: string;
    name: {
      givenName: string;
      familyName: string;
      fullName: string;
    };
    emailAddress: string;
  };
}

interface ClassroomAssignment {
  courseId: string;
  id: string;
  title: string;
  description: string;
  materials: any[];
  state: string;
  alternateLink: string;
  creationTime: string;
  updateTime: string;
  maxPoints: number;
  workType: string;
  submissionModificationMode: string;
}

export class GoogleClassroomService {
  private config: ClassroomConfig | null = null;

  constructor() {
    this.loadConfig();
  }

  private loadConfig(): void {
    const stored = localStorage.getItem('classroom-config');
    if (stored) {
      this.config = JSON.parse(stored);
    }
  }

  setConfig(accessToken: string): void {
    this.config = { accessToken };
    localStorage.setItem('classroom-config', JSON.stringify(this.config));
  }

  isConfigured(): boolean {
    return !!this.config?.accessToken;
  }

  private async makeRequest(endpoint: string, options: RequestInit = {}): Promise<any> {
    if (!this.config) {
      throw new Error('Google Classroom not configured');
    }

    const url = `https://classroom.googleapis.com/v1${endpoint}`;
    
    const response = await fetch(url, {
      ...options,
      headers: {
        'Authorization': `Bearer ${this.config.accessToken}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`Classroom API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async getCourses(): Promise<ClassroomCourse[]> {
    const response = await this.makeRequest('/courses?pageSize=100');
    return response.courses || [];
  }

  async getStudents(courseId: string): Promise<ClassroomStudent[]> {
    const response = await this.makeRequest(`/courses/${courseId}/students?pageSize=100`);
    return response.students || [];
  }

  async getCourseWork(courseId: string): Promise<ClassroomAssignment[]> {
    const response = await this.makeRequest(`/courses/${courseId}/courseWork?pageSize=100`);
    return response.courseWork || [];
  }

  async createAssignment(courseId: string, assignment: {
    title: string;
    description: string;
    maxPoints?: number;
    dueDate?: Date;
    materials?: any[];
  }): Promise<ClassroomAssignment> {
    const body: any = {
      title: assignment.title,
      description: assignment.description,
      workType: 'ASSIGNMENT',
      state: 'PUBLISHED',
    };

    if (assignment.maxPoints) {
      body.maxPoints = assignment.maxPoints;
    }

    if (assignment.dueDate) {
      const date = assignment.dueDate;
      body.dueDate = {
        year: date.getFullYear(),
        month: date.getMonth() + 1,
        day: date.getDate(),
      };
    }

    if (assignment.materials) {
      body.materials = assignment.materials;
    }

    return this.makeRequest(`/courses/${courseId}/courseWork`, {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  async createNumberScriptAssignment(
    courseId: string,
    title: string,
    description: string,
    dueDate?: Date,
    maxPoints?: number
  ): Promise<ClassroomAssignment> {
    const assignment = {
      title: `NumberScript: ${title}`,
      description: `${description}\n\nComplete this assignment using NumberScript. Submit your .numscript file when finished.`,
      maxPoints: maxPoints || 100,
      dueDate,
      materials: [{
        link: {
          url: window.location.origin,
          title: 'NumberScript IDE',
          thumbnailUrl: '',
        }
      }],
    };

    return this.createAssignment(courseId, assignment);
  }

  async getSubmissions(courseId: string, courseWorkId: string): Promise<any[]> {
    const response = await this.makeRequest(`/courses/${courseId}/courseWork/${courseWorkId}/studentSubmissions?pageSize=100`);
    return response.studentSubmissions || [];
  }

  async gradeSubmission(
    courseId: string,
    courseWorkId: string,
    submissionId: string,
    grade: number,
    feedback?: string
  ): Promise<any> {
    const body: any = {
      assignedGrade: grade,
      draftGrade: grade,
    };

    // First, patch the grade
    const gradeResponse = await this.makeRequest(
      `/courses/${courseId}/courseWork/${courseWorkId}/studentSubmissions/${submissionId}:patch?updateMask=assignedGrade,draftGrade`,
      {
        method: 'PATCH',
        body: JSON.stringify(body),
      }
    );

    // If feedback is provided, add it as a comment
    if (feedback) {
      await this.makeRequest(
        `/courses/${courseId}/courseWork/${courseWorkId}/studentSubmissions/${submissionId}/comments`,
        {
          method: 'POST',
          body: JSON.stringify({
            comment: feedback
          }),
        }
      );
    }

    return gradeResponse;
  }

  async getProfile(): Promise<any> {
    return this.makeRequest('/userProfiles/me');
  }

  clearConfig(): void {
    this.config = null;
    localStorage.removeItem('classroom-config');
  }
}

export const googleClassroomService = new GoogleClassroomService();