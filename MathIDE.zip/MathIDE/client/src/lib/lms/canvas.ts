interface CanvasConfig {
  baseUrl: string;
  accessToken: string;
}

interface CanvasCourse {
  id: number;
  name: string;
  course_code: string;
  enrollment_term_id: number;
}

interface CanvasUser {
  id: number;
  name: string;
  sortable_name: string;
  short_name: string;
  login_id: string;
  email: string;
}

interface CanvasAssignment {
  id: number;
  name: string;
  description: string;
  due_at: string;
  points_possible: number;
  course_id: number;
}

export class CanvasLMSService {
  private config: CanvasConfig | null = null;

  constructor() {
    this.loadConfig();
  }

  private loadConfig(): void {
    const stored = localStorage.getItem('canvas-config');
    if (stored) {
      this.config = JSON.parse(stored);
    }
  }

  setConfig(baseUrl: string, accessToken: string): void {
    this.config = { baseUrl, accessToken };
    localStorage.setItem('canvas-config', JSON.stringify(this.config));
  }

  isConfigured(): boolean {
    return !!this.config?.baseUrl && !!this.config?.accessToken;
  }

  private async makeRequest(endpoint: string, options: RequestInit = {}): Promise<any> {
    if (!this.config) {
      throw new Error('Canvas LMS not configured');
    }

    const url = `${this.config.baseUrl}/api/v1${endpoint}`;
    
    const response = await fetch(url, {
      ...options,
      headers: {
        'Authorization': `Bearer ${this.config.accessToken}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`Canvas API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async getCourses(): Promise<CanvasCourse[]> {
    return this.makeRequest('/courses?enrollment_state=active&per_page=100');
  }

  async getCourseStudents(courseId: number): Promise<CanvasUser[]> {
    return this.makeRequest(`/courses/${courseId}/users?enrollment_type[]=student&per_page=100`);
  }

  async getAssignments(courseId: number): Promise<CanvasAssignment[]> {
    return this.makeRequest(`/courses/${courseId}/assignments?per_page=100`);
  }

  async createAssignment(courseId: number, assignment: {
    name: string;
    description: string;
    due_at?: string;
    points_possible?: number;
    submission_types?: string[];
  }): Promise<CanvasAssignment> {
    return this.makeRequest(`/courses/${courseId}/assignments`, {
      method: 'POST',
      body: JSON.stringify({
        assignment: {
          ...assignment,
          submission_types: assignment.submission_types || ['online_upload'],
        }
      }),
    });
  }

  async createNumberScriptAssignment(
    courseId: number,
    title: string,
    description: string,
    dueDate?: Date,
    points?: number
  ): Promise<CanvasAssignment> {
    const assignment = {
      name: `NumberScript: ${title}`,
      description: `${description}\n\nSubmit your NumberScript (.numscript) file for this assignment.`,
      due_at: dueDate?.toISOString(),
      points_possible: points || 100,
      submission_types: ['online_upload'],
    };

    return this.createAssignment(courseId, assignment);
  }

  async getSubmissions(courseId: number, assignmentId: number): Promise<any[]> {
    return this.makeRequest(`/courses/${courseId}/assignments/${assignmentId}/submissions?include[]=user&per_page=100`);
  }

  async gradeSubmission(
    courseId: number,
    assignmentId: number,
    userId: number,
    score: number,
    comment?: string
  ): Promise<any> {
    const body: any = {
      submission: {
        posted_grade: score
      }
    };

    if (comment) {
      body.comment = {
        text_comment: comment
      };
    }

    return this.makeRequest(`/courses/${courseId}/assignments/${assignmentId}/submissions/${userId}`, {
      method: 'PUT',
      body: JSON.stringify(body),
    });
  }

  clearConfig(): void {
    this.config = null;
    localStorage.removeItem('canvas-config');
  }
}

export const canvasService = new CanvasLMSService();