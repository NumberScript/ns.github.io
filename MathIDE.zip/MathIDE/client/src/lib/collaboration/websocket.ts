interface CollaborationMessage {
  type: 'connected' | 'join-session' | 'leave-session' | 'text-operation' | 'cursor-update' | 'user-joined' | 'user-left' | 'session-joined';
  userId?: string;
  fileId?: string;
  operation?: TextOperation;
  position?: number;
  participants?: number;
  timestamp?: number;
  message?: string;
}

interface TextOperation {
  type: 'insert' | 'delete' | 'retain';
  position: number;
  content?: string;
  length?: number;
}

interface CollaborativeUser {
  id: string;
  name: string;
  color: string;
  cursor?: number;
}

export class CollaborationService {
  private ws: WebSocket | null = null;
  private currentFileId: string | null = null;
  private userId: string;
  private callbacks: Map<string, Function[]> = new Map();
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;

  constructor() {
    this.userId = this.generateUserId();
    this.connect();
  }

  private generateUserId(): string {
    return `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private connect(): void {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    try {
      this.ws = new WebSocket(wsUrl);
      
      this.ws.onopen = () => {
        console.log('Connected to collaboration server');
        this.reconnectAttempts = 0;
        this.emit('connected');
      };

      this.ws.onmessage = (event) => {
        try {
          const message: CollaborationMessage = JSON.parse(event.data);
          this.handleMessage(message);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      this.ws.onclose = () => {
        console.log('Disconnected from collaboration server');
        this.emit('disconnected');
        this.attemptReconnect();
      };

      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        this.emit('error', error);
      };
    } catch (error) {
      console.error('Failed to connect to WebSocket server:', error);
      this.attemptReconnect();
    }
  }

  private attemptReconnect(): void {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = Math.pow(2, this.reconnectAttempts) * 1000; // Exponential backoff
      
      console.log(`Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts}) in ${delay}ms`);
      
      setTimeout(() => {
        this.connect();
      }, delay);
    }
  }

  private handleMessage(message: CollaborationMessage): void {
    switch (message.type) {
      case 'connected':
        this.emit('connected', message);
        break;
      case 'session-joined':
        this.emit('session-joined', message);
        break;
      case 'user-joined':
        this.emit('user-joined', message);
        break;
      case 'user-left':
        this.emit('user-left', message);
        break;
      case 'text-operation':
        this.emit('text-operation', message);
        break;
      case 'cursor-update':
        this.emit('cursor-update', message);
        break;
    }
  }

  joinSession(fileId: string): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.currentFileId = fileId;
      this.send({
        type: 'join-session',
        fileId,
        userId: this.userId
      });
    }
  }

  leaveSession(): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.currentFileId) {
      this.send({
        type: 'leave-session',
        fileId: this.currentFileId,
        userId: this.userId
      });
      this.currentFileId = null;
    }
  }

  sendTextOperation(operation: TextOperation): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.currentFileId) {
      this.send({
        type: 'text-operation',
        fileId: this.currentFileId,
        userId: this.userId,
        operation
      });
    }
  }

  sendCursorUpdate(position: number): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.currentFileId) {
      this.send({
        type: 'cursor-update',
        fileId: this.currentFileId,
        userId: this.userId,
        position
      });
    }
  }

  private send(message: CollaborationMessage): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  on(event: string, callback: Function): void {
    if (!this.callbacks.has(event)) {
      this.callbacks.set(event, []);
    }
    this.callbacks.get(event)!.push(callback);
  }

  off(event: string, callback: Function): void {
    const callbacks = this.callbacks.get(event);
    if (callbacks) {
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    }
  }

  private emit(event: string, data?: any): void {
    const callbacks = this.callbacks.get(event);
    if (callbacks) {
      callbacks.forEach(callback => callback(data));
    }
  }

  getUserId(): string {
    return this.userId;
  }

  isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  disconnect(): void {
    if (this.ws) {
      this.leaveSession();
      this.ws.close();
    }
  }
}

export const collaborationService = new CollaborationService();