export interface NumberScriptPlugin {
  id: string;
  name: string;
  version: string;
  description: string;
  author: string;
  functions: PluginFunction[];
  dependencies?: string[];
  config?: Record<string, any>;
}

export interface PluginFunction {
  name: string;
  description: string;
  parameters: PluginParameter[];
  returnType: 'number' | 'string' | 'boolean' | 'array' | 'object';
  category: 'arithmetic' | 'trigonometry' | 'calculus' | 'statistics' | 'linear-algebra' | 'utility' | 'custom';
  implementation: (...args: any[]) => any;
}

export interface PluginParameter {
  name: string;
  type: 'number' | 'string' | 'boolean' | 'array' | 'object';
  required: boolean;
  description: string;
  defaultValue?: any;
  validation?: (value: any) => boolean;
}

export interface PluginRegistry {
  [pluginId: string]: NumberScriptPlugin;
}

export class PluginManager {
  private plugins: PluginRegistry = {};
  private enabledPlugins: Set<string> = new Set();
  private functionRegistry: Map<string, PluginFunction> = new Map();

  constructor() {
    this.loadPluginsFromStorage();
    this.registerBuiltInPlugins();
  }

  // Plugin Management
  registerPlugin(plugin: NumberScriptPlugin): void {
    if (this.plugins[plugin.id]) {
      console.warn(`Plugin ${plugin.id} is already registered, skipping`);
      return;
    }

    // Validate plugin structure
    this.validatePlugin(plugin);

    // Register the plugin
    this.plugins[plugin.id] = plugin;
    
    // Register functions if plugin is enabled
    if (this.enabledPlugins.has(plugin.id)) {
      this.registerPluginFunctions(plugin);
    }

    this.savePluginsToStorage();
  }

  unregisterPlugin(pluginId: string): void {
    const plugin = this.plugins[pluginId];
    if (!plugin) {
      throw new Error(`Plugin ${pluginId} not found`);
    }

    // Unregister functions
    this.unregisterPluginFunctions(plugin);
    
    // Remove from registry
    delete this.plugins[pluginId];
    this.enabledPlugins.delete(pluginId);
    
    this.savePluginsToStorage();
  }

  enablePlugin(pluginId: string): void {
    const plugin = this.plugins[pluginId];
    if (!plugin) {
      throw new Error(`Plugin ${pluginId} not found`);
    }

    if (this.enabledPlugins.has(pluginId)) {
      return; // Already enabled
    }

    // Check dependencies
    if (plugin.dependencies) {
      for (const depId of plugin.dependencies) {
        if (!this.enabledPlugins.has(depId)) {
          throw new Error(`Plugin ${pluginId} requires ${depId} to be enabled`);
        }
      }
    }

    this.enabledPlugins.add(pluginId);
    this.registerPluginFunctions(plugin);
    this.savePluginsToStorage();
  }

  disablePlugin(pluginId: string): void {
    const plugin = this.plugins[pluginId];
    if (!plugin) {
      throw new Error(`Plugin ${pluginId} not found`);
    }

    // Check if other plugins depend on this one
    for (const [id, p] of Object.entries(this.plugins)) {
      if (this.enabledPlugins.has(id) && p.dependencies?.includes(pluginId)) {
        throw new Error(`Cannot disable ${pluginId} because ${id} depends on it`);
      }
    }

    this.enabledPlugins.delete(pluginId);
    this.unregisterPluginFunctions(plugin);
    this.savePluginsToStorage();
  }

  // Function Registry
  getFunction(name: string): PluginFunction | undefined {
    return this.functionRegistry.get(name);
  }

  getAllFunctions(): Map<string, PluginFunction> {
    return new Map(this.functionRegistry);
  }

  getFunctionsByCategory(category: string): PluginFunction[] {
    return Array.from(this.functionRegistry.values())
      .filter(func => func.category === category);
  }

  executeFunction(name: string, ...args: any[]): any {
    const func = this.functionRegistry.get(name);
    if (!func) {
      throw new Error(`Function ${name} not found`);
    }

    // Validate parameters
    this.validateFunctionCall(func, args);

    try {
      return func.implementation(...args);
    } catch (error) {
      throw new Error(`Error executing function ${name}: ${error}`);
    }
  }

  // Plugin Information
  getPlugins(): NumberScriptPlugin[] {
    return Object.values(this.plugins);
  }

  getEnabledPlugins(): NumberScriptPlugin[] {
    return Object.values(this.plugins).filter(p => this.enabledPlugins.has(p.id));
  }

  isPluginEnabled(pluginId: string): boolean {
    return this.enabledPlugins.has(pluginId);
  }

  // Plugin Creation Helper
  createPlugin(
    id: string,
    name: string,
    version: string,
    description: string,
    author: string,
    functions: PluginFunction[]
  ): NumberScriptPlugin {
    return {
      id,
      name,
      version,
      description,
      author,
      functions,
    };
  }

  // Private Methods
  private validatePlugin(plugin: NumberScriptPlugin): void {
    if (!plugin.id || !plugin.name || !plugin.version) {
      throw new Error('Plugin must have id, name, and version');
    }

    if (!plugin.functions || plugin.functions.length === 0) {
      throw new Error('Plugin must have at least one function');
    }

    // Validate each function
    plugin.functions.forEach(func => {
      if (!func.name || !func.implementation) {
        throw new Error('Each function must have a name and implementation');
      }
    });
  }

  private validateFunctionCall(func: PluginFunction, args: any[]): void {
    const requiredParams = func.parameters.filter(p => p.required);
    
    if (args.length < requiredParams.length) {
      throw new Error(`Function ${func.name} requires ${requiredParams.length} parameters`);
    }

    // Validate parameter types
    func.parameters.forEach((param, index) => {
      if (index < args.length) {
        const value = args[index];
        if (!this.validateParameterType(value, param.type)) {
          throw new Error(`Parameter ${param.name} must be of type ${param.type}`);
        }

        if (param.validation && !param.validation(value)) {
          throw new Error(`Parameter ${param.name} failed validation`);
        }
      }
    });
  }

  private validateParameterType(value: any, type: string): boolean {
    switch (type) {
      case 'number':
        return typeof value === 'number' && !isNaN(value);
      case 'string':
        return typeof value === 'string';
      case 'boolean':
        return typeof value === 'boolean';
      case 'array':
        return Array.isArray(value);
      case 'object':
        return typeof value === 'object' && value !== null && !Array.isArray(value);
      default:
        return true;
    }
  }

  private registerPluginFunctions(plugin: NumberScriptPlugin): void {
    plugin.functions.forEach(func => {
      if (this.functionRegistry.has(func.name)) {
        console.warn(`Function ${func.name} is already registered, skipping`);
        return;
      }
      this.functionRegistry.set(func.name, func);
    });
  }

  private unregisterPluginFunctions(plugin: NumberScriptPlugin): void {
    plugin.functions.forEach(func => {
      this.functionRegistry.delete(func.name);
    });
  }

  private savePluginsToStorage(): void {
    const data = {
      plugins: this.plugins,
      enabledPlugins: Array.from(this.enabledPlugins),
    };
    localStorage.setItem('numberscript-plugins', JSON.stringify(data));
  }

  private loadPluginsFromStorage(): void {
    const stored = localStorage.getItem('numberscript-plugins');
    if (stored) {
      try {
        const data = JSON.parse(stored);
        this.plugins = data.plugins || {};
        this.enabledPlugins = new Set(data.enabledPlugins || []);
        
        // Re-register enabled plugins
        Array.from(this.enabledPlugins).forEach(pluginId => {
          const plugin = this.plugins[pluginId];
          if (plugin) {
            this.registerPluginFunctions(plugin);
          }
        });
      } catch (error) {
        console.error('Failed to load plugins from storage:', error);
      }
    }
  }

  private registerBuiltInPlugins(): void {
    // Statistics Plugin
    const statsPlugin: NumberScriptPlugin = {
      id: 'core-statistics',
      name: 'Core Statistics',
      version: '1.0.0',
      description: 'Basic statistical functions',
      author: 'NumberScript Core',
      functions: [
        {
          name: 'mean',
          description: 'Calculate the arithmetic mean of a dataset',
          parameters: [
            {
              name: 'data',
              type: 'array',
              required: true,
              description: 'Array of numbers',
              validation: (val) => Array.isArray(val) && val.every(x => typeof x === 'number')
            }
          ],
          returnType: 'number',
          category: 'statistics',
          implementation: (data: number[]) => data.reduce((a, b) => a + b, 0) / data.length
        },
        {
          name: 'median',
          description: 'Calculate the median of a dataset',
          parameters: [
            {
              name: 'data',
              type: 'array',
              required: true,
              description: 'Array of numbers',
              validation: (val) => Array.isArray(val) && val.every(x => typeof x === 'number')
            }
          ],
          returnType: 'number',
          category: 'statistics',
          implementation: (data: number[]) => {
            const sorted = [...data].sort((a, b) => a - b);
            const mid = Math.floor(sorted.length / 2);
            return sorted.length % 2 === 0 
              ? (sorted[mid - 1] + sorted[mid]) / 2 
              : sorted[mid];
          }
        }
      ]
    };

    this.registerPlugin(statsPlugin);
    this.enablePlugin('core-statistics');
  }
}

export const pluginManager = new PluginManager();