export interface NumberScriptValue {
  type: "number" | "expression" | "function" | "variable" | "boolean";
  value: any;
  raw?: string;
}

export interface MathStep {
  title: string;
  steps: string[];
  result: string;
  status: "complete" | "in-progress" | "pending";
}

export interface EvaluationResult {
  output: string;
  steps: MathStep[];
  variables: Record<string, any>;
  errors: string[];
}

export interface NumberScriptAST {
  type: "program" | "assignment" | "expression" | "solve" | "function_call";
  children?: NumberScriptAST[];
  value?: any;
  identifier?: string;
  operator?: string;
  function?: string;
  arguments?: NumberScriptAST[];
}
