import { NumberScriptAST, NumberScriptValue } from "./types";

export class NumberScriptParser {
  private tokens: string[] = [];
  private current = 0;

  parse(input: string): NumberScriptAST {
    this.tokens = this.tokenize(input);
    this.current = 0;
    return this.parseProgram();
  }

  private tokenize(input: string): string[] {
    // Simple tokenizer for NumberScript
    const tokenRegex = /(\w+|[+\-*/^()=<>!]+|[\d.]+|"[^"]*"|\/\/.*)/g;
    const tokens = input.match(tokenRegex) || [];
    return tokens.filter(token => !token.startsWith("//") && token.trim());
  }

  private parseProgram(): NumberScriptAST {
    const statements: NumberScriptAST[] = [];
    
    while (!this.isAtEnd()) {
      const stmt = this.parseStatement();
      if (stmt) statements.push(stmt);
    }

    return {
      type: "program",
      children: statements,
    };
  }

  private parseStatement(): NumberScriptAST | null {
    if (this.match("solve")) {
      return this.parseSolveStatement();
    }
    
    if (this.match("let")) {
      return this.parseAssignment();
    }

    if (this.check("showWork")) {
      return this.parseShowWorkStatement();
    }

    // Try to parse as expression
    try {
      return this.parseExpression();
    } catch {
      this.advance(); // Skip invalid tokens
      return null;
    }
  }

  private parseSolveStatement(): NumberScriptAST {
    const expression = this.parseExpression();
    return {
      type: "solve",
      children: [expression],
    };
  }

  private parseAssignment(): NumberScriptAST {
    const identifier = this.advance();
    this.consume("=", "Expected '=' after variable name");
    const value = this.parseExpression();
    
    return {
      type: "assignment",
      identifier,
      children: [value],
    };
  }

  private parseShowWorkStatement(): NumberScriptAST {
    this.advance(); // consume 'showWork'
    this.consume("==", "Expected '==' after showWork");
    const value = this.advance(); // true or false
    
    return {
      type: "assignment",
      identifier: "showWork",
      value: value === "true",
    };
  }

  private parseExpression(): NumberScriptAST {
    return this.parseAddition();
  }

  private parseAddition(): NumberScriptAST {
    let expr = this.parseMultiplication();

    while (this.match("+", "-")) {
      const operator = this.previous();
      const right = this.parseMultiplication();
      expr = {
        type: "expression",
        operator,
        children: [expr, right],
      };
    }

    return expr;
  }

  private parseMultiplication(): NumberScriptAST {
    let expr = this.parseExponentiation();

    while (this.match("*", "/")) {
      const operator = this.previous();
      const right = this.parseExponentiation();
      expr = {
        type: "expression",
        operator,
        children: [expr, right],
      };
    }

    return expr;
  }

  private parseExponentiation(): NumberScriptAST {
    let expr = this.parsePrimary();

    while (this.match("^", "**")) {
      const operator = this.previous();
      const right = this.parsePrimary();
      expr = {
        type: "expression",
        operator,
        children: [expr, right],
      };
    }

    return expr;
  }

  private parsePrimary(): NumberScriptAST {
    if (this.match("(")) {
      const expr = this.parseExpression();
      this.consume(")", "Expected ')' after expression");
      return expr;
    }

    if (this.isNumber(this.peek())) {
      return {
        type: "expression",
        value: parseFloat(this.advance()),
      };
    }

    if (this.isIdentifier(this.peek())) {
      const identifier = this.advance();
      
      // Check if it's a function call
      if (this.match("(")) {
        const args: NumberScriptAST[] = [];
        
        if (!this.check(")")) {
          do {
            args.push(this.parseExpression());
          } while (this.match(","));
        }
        
        this.consume(")", "Expected ')' after function arguments");
        
        return {
          type: "function_call",
          function: identifier,
          arguments: args,
        };
      }
      
      return {
        type: "expression",
        identifier,
      };
    }

    throw new Error(`Unexpected token: ${this.peek()}`);
  }

  private match(...types: string[]): boolean {
    for (const type of types) {
      if (this.check(type)) {
        this.advance();
        return true;
      }
    }
    return false;
  }

  private check(type: string): boolean {
    if (this.isAtEnd()) return false;
    return this.peek() === type;
  }

  private advance(): string {
    if (!this.isAtEnd()) this.current++;
    return this.previous();
  }

  private isAtEnd(): boolean {
    return this.current >= this.tokens.length;
  }

  private peek(): string {
    return this.tokens[this.current] || "";
  }

  private previous(): string {
    return this.tokens[this.current - 1] || "";
  }

  private consume(type: string, message: string): string {
    if (this.check(type)) return this.advance();
    throw new Error(message);
  }

  private isNumber(token: string): boolean {
    return !isNaN(parseFloat(token)) && isFinite(parseFloat(token));
  }

  private isIdentifier(token: string): boolean {
    return /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(token);
  }
}
