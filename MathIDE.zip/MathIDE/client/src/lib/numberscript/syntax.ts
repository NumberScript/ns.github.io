export class NumberScriptSyntax {
  private static keywords = [
    "solve", "let", "showWork", "true", "false", "if", "else", "for", "while"
  ];

  private static functions = [
    "sin", "cos", "tan", "asin", "acos", "atan", "sqrt", "log", "ln", "abs", 
    "floor", "ceil", "round", "derive", "integrate", "limit", "series",
    "factor", "expand", "simplify"
  ];

  private static operators = ["+", "-", "*", "/", "^", "**", "=", "==", "(", ")", "<", ">"];

  static highlight(code: string): string {
    let highlighted = code;

    // Comments
    highlighted = highlighted.replace(
      /\/\/.*/g, 
      '<span class="numberscript-comment">$&</span>'
    );

    // Numbers
    highlighted = highlighted.replace(
      /\b\d+\.?\d*\b/g, 
      '<span class="numberscript-number">$&</span>'
    );

    // Keywords
    this.keywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, 'g');
      highlighted = highlighted.replace(
        regex, 
        `<span class="numberscript-keyword">${keyword}</span>`
      );
    });

    // Functions
    this.functions.forEach(func => {
      const regex = new RegExp(`\\b${func}(?=\\s*\\()`, 'g');
      highlighted = highlighted.replace(
        regex, 
        `<span class="numberscript-function">${func}</span>`
      );
    });

    // Operators
    this.operators.forEach(op => {
      const escapedOp = op.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(escapedOp, 'g');
      highlighted = highlighted.replace(
        regex, 
        `<span class="numberscript-operator">${op}</span>`
      );
    });

    return highlighted;
  }

  static getCompletions(position: number, code: string): string[] {
    // Simple completion based on context
    const beforeCursor = code.substring(0, position);
    const lastWord = beforeCursor.split(/\s+/).pop() || "";

    if (lastWord.endsWith("(")) {
      return this.functions;
    }

    if (beforeCursor.includes("solve")) {
      return ["sin", "cos", "tan", "sqrt", "log", "+", "-", "*", "/", "^"];
    }

    return [...this.keywords, ...this.functions];
  }

  static validateSyntax(code: string): string[] {
    const errors: string[] = [];
    
    // Basic syntax validation
    const openParens = (code.match(/\(/g) || []).length;
    const closeParens = (code.match(/\)/g) || []).length;
    
    if (openParens !== closeParens) {
      errors.push("Unmatched parentheses");
    }

    return errors;
  }
}
