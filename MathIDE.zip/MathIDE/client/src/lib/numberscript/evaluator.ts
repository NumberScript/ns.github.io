import { NumberScriptParser } from "./parser";
import { NumberScriptAST, MathStep, EvaluationResult } from "./types";
import { advancedMath } from "./advanced";
import { pluginManager } from "../plugins/manager";

export class NumberScriptEvaluator {
  private variables: Record<string, any> = {};
  private steps: MathStep[] = [];
  private parser = new NumberScriptParser();

  evaluateWithSteps(code: string): EvaluationResult {
    this.steps = [];
    this.variables = {};
    
    try {
      const ast = this.parser.parse(code);
      const result = this.evaluateAST(ast);
      
      return {
        output: String(result),
        steps: this.steps,
        variables: this.variables,
        errors: [],
      };
    } catch (error) {
      return {
        output: "",
        steps: this.steps,
        variables: this.variables,
        errors: [String(error)],
      };
    }
  }

  private evaluateAST(node: NumberScriptAST): any {
    switch (node.type) {
      case "program":
        let result: any = null;
        if (node.children) {
          for (const child of node.children) {
            result = this.evaluateAST(child);
          }
        }
        return result;

      case "assignment":
        if (node.identifier && node.children) {
          const value = this.evaluateAST(node.children[0]);
          this.variables[node.identifier] = value;
          return value;
        } else if (node.identifier && node.value !== undefined) {
          this.variables[node.identifier] = node.value;
          return node.value;
        }
        break;

      case "solve":
        if (node.children) {
          const expression = node.children[0];
          const result = this.evaluateAST(expression);
          
          this.addMathStep({
            title: "Solve Expression",
            steps: [
              `Expression: ${this.astToString(expression)}`,
              `Calculating...`,
            ],
            result: String(result),
            status: "complete",
          });
          
          return result;
        }
        break;

      case "expression":
        if (node.value !== undefined) {
          return node.value;
        }
        
        if (node.identifier) {
          return this.variables[node.identifier] || 0;
        }
        
        if (node.operator && node.children && node.children.length === 2) {
          const left = this.evaluateAST(node.children[0]);
          const right = this.evaluateAST(node.children[1]);
          
          return this.evaluateOperation(left, node.operator, right);
        }
        break;

      case "function_call":
        if (node.function && node.arguments) {
          const args = node.arguments.map(arg => this.evaluateAST(arg));
          return this.evaluateFunction(node.function, args);
        }
        break;
    }

    return 0;
  }

  private evaluateOperation(left: number, operator: string, right: number): number {
    switch (operator) {
      case "+":
        return left + right;
      case "-":
        return left - right;
      case "*":
        return left * right;
      case "/":
        return right !== 0 ? left / right : 0;
      case "^":
      case "**":
        return Math.pow(left, right);
      default:
        return 0;
    }
  }

  private evaluateFunction(funcName: string, args: number[]): number {
    // First check if it's a plugin function
    try {
      const result = pluginManager.executeFunction(funcName, ...args);
      if (typeof result === 'number') {
        return result;
      }
    } catch (error) {
      // Function not found in plugins, try built-in functions
    }

    // Built-in mathematical functions
    switch (funcName) {
      case "sqrt":
        return Math.sqrt(args[0] || 0);
      case "sin":
        return Math.sin(args[0] || 0);
      case "cos":
        return Math.cos(args[0] || 0);
      case "tan":
        return Math.tan(args[0] || 0);
      case "asin":
        return Math.asin(args[0] || 0);
      case "acos":
        return Math.acos(args[0] || 0);
      case "atan":
        return Math.atan(args[0] || 0);
      case "log":
        return Math.log(args[0] || 1);
      case "ln":
        return Math.log(args[0] || 1);
      case "abs":
        return Math.abs(args[0] || 0);
      case "floor":
        return Math.floor(args[0] || 0);
      case "ceil":
        return Math.ceil(args[0] || 0);
      case "round":
        return Math.round(args[0] || 0);
      
      // Advanced mathematical functions
      case "factorial":
        return advancedMath.factorial(args[0] || 0);
      case "fibonacci":
        return advancedMath.fibonacci(args[0] || 0);
      case "gcd":
        return advancedMath.gcd(args[0] || 0, args[1] || 0);
      case "lcm":
        return advancedMath.lcm(args[0] || 0, args[1] || 0);
      case "isPrime":
        return advancedMath.isPrime(args[0] || 0) ? 1 : 0;
      
      // Statistics functions (for single values)
      case "mean":
        return args.reduce((sum, val) => sum + val, 0) / args.length;
      
      default:
        return 0;
    }
  }

  private astToString(node: NumberScriptAST): string {
    switch (node.type) {
      case "expression":
        if (node.value !== undefined) return String(node.value);
        if (node.identifier) return node.identifier;
        if (node.operator && node.children) {
          const left = this.astToString(node.children[0]);
          const right = this.astToString(node.children[1]);
          return `${left} ${node.operator} ${right}`;
        }
        break;
      case "function_call":
        if (node.function && node.arguments) {
          const args = node.arguments.map(arg => this.astToString(arg)).join(", ");
          return `${node.function}(${args})`;
        }
        break;
    }
    return "";
  }

  private addMathStep(step: MathStep) {
    this.steps.push(step);
  }
}
