import { NumberScriptAST, EvaluationResult, MathStep } from "./types";

export interface GraphData {
  type: 'function' | 'scatter' | 'line' | 'bar';
  data: { x: number; y: number }[];
  label: string;
  color: string;
}

export interface StatisticsResult {
  mean: number;
  median: number;
  mode: number[];
  standardDeviation: number;
  variance: number;
  min: number;
  max: number;
  range: number;
  count: number;
}

export class AdvancedNumberScript {
  private variables: Record<string, any> = {};
  private graphData: GraphData[] = [];

  // Advanced Mathematical Functions
  
  // Calculus Functions
  derivative(expression: string, variable: string = 'x'): string {
    // Simplified symbolic differentiation
    const rules: Record<string, string> = {
      // Power rule: d/dx(x^n) = n*x^(n-1)
      'x': '1',
      'x^2': '2*x',
      'x^3': '3*x^2',
      'sin(x)': 'cos(x)',
      'cos(x)': '-sin(x)',
      'tan(x)': 'sec(x)^2',
      'ln(x)': '1/x',
      'e^x': 'e^x',
    };

    return rules[expression] || `d/d${variable}(${expression})`;
  }

  integral(expression: string, variable: string = 'x', lowerBound?: number, upperBound?: number): number | string {
    // Simplified integration using numerical methods
    if (lowerBound !== undefined && upperBound !== undefined) {
      return this.numericalIntegration(expression, variable, lowerBound, upperBound);
    }
    
    // Symbolic integration (simplified)
    const integrals: Record<string, string> = {
      'x': 'x^2/2',
      'x^2': 'x^3/3',
      'x^3': 'x^4/4',
      '1': 'x',
      'sin(x)': '-cos(x)',
      'cos(x)': 'sin(x)',
      '1/x': 'ln(|x|)',
    };

    return integrals[expression] || `∫${expression} d${variable}`;
  }

  private numericalIntegration(expression: string, variable: string, a: number, b: number, n: number = 1000): number {
    // Simpson's rule for numerical integration
    const h = (b - a) / n;
    let sum = this.evaluateExpression(expression, variable, a) + this.evaluateExpression(expression, variable, b);
    
    for (let i = 1; i < n; i++) {
      const x = a + i * h;
      const multiplier = i % 2 === 0 ? 2 : 4;
      sum += multiplier * this.evaluateExpression(expression, variable, x);
    }
    
    return (h / 3) * sum;
  }

  private evaluateExpression(expression: string, variable: string, value: number): number {
    // Simple expression evaluator for numerical methods
    const expr = expression.replace(new RegExp(variable, 'g'), value.toString());
    
    try {
      // Basic math expression evaluation
      if (expr.includes('sin')) return Math.sin(value);
      if (expr.includes('cos')) return Math.cos(value);
      if (expr.includes('tan')) return Math.tan(value);
      if (expr.includes('ln')) return Math.log(value);
      if (expr.includes('log')) return Math.log10(value);
      if (expr.includes('sqrt')) return Math.sqrt(value);
      if (expr.includes('exp')) return Math.exp(value);
      
      return eval(expr.replace(/\^/g, '**'));
    } catch {
      return 0;
    }
  }

  // Graphing Functions
  plot(expression: string, xMin: number = -10, xMax: number = 10, step: number = 0.1): GraphData {
    const data: { x: number; y: number }[] = [];
    
    for (let x = xMin; x <= xMax; x += step) {
      try {
        const y = this.evaluateExpression(expression, 'x', x);
        if (isFinite(y)) {
          data.push({ x, y });
        }
      } catch (error) {
        // Skip invalid points
      }
    }

    const graphData: GraphData = {
      type: 'function',
      data,
      label: expression,
      color: this.generateRandomColor(),
    };

    this.graphData.push(graphData);
    return graphData;
  }

  scatter(xData: number[], yData: number[], label?: string): GraphData {
    if (xData.length !== yData.length) {
      throw new Error('X and Y data arrays must have the same length');
    }

    const data = xData.map((x, i) => ({ x, y: yData[i] }));
    
    const graphData: GraphData = {
      type: 'scatter',
      data,
      label: label || 'Scatter Plot',
      color: this.generateRandomColor(),
    };

    this.graphData.push(graphData);
    return graphData;
  }

  private generateRandomColor(): string {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  // Statistics Functions
  statistics(data: number[]): StatisticsResult {
    if (data.length === 0) {
      throw new Error('Data array cannot be empty');
    }

    const sorted = [...data].sort((a, b) => a - b);
    const sum = data.reduce((acc, val) => acc + val, 0);
    const mean = sum / data.length;

    // Median
    const median = sorted.length % 2 === 0
      ? (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
      : sorted[Math.floor(sorted.length / 2)];

    // Mode
    const frequency: Record<number, number> = {};
    data.forEach(val => frequency[val] = (frequency[val] || 0) + 1);
    const maxFreq = Math.max(...Object.values(frequency));
    const mode = Object.keys(frequency)
      .filter(key => frequency[Number(key)] === maxFreq)
      .map(Number);

    // Variance and Standard Deviation
    const variance = data.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / data.length;
    const standardDeviation = Math.sqrt(variance);

    return {
      mean,
      median,
      mode,
      standardDeviation,
      variance,
      min: Math.min(...data),
      max: Math.max(...data),
      range: Math.max(...data) - Math.min(...data),
      count: data.length,
    };
  }

  // Linear Algebra Functions
  matrixMultiply(a: number[][], b: number[][]): number[][] {
    const result: number[][] = [];
    
    if (a[0].length !== b.length) {
      throw new Error('Invalid matrix dimensions for multiplication');
    }

    for (let i = 0; i < a.length; i++) {
      result[i] = [];
      for (let j = 0; j < b[0].length; j++) {
        let sum = 0;
        for (let k = 0; k < a[0].length; k++) {
          sum += a[i][k] * b[k][j];
        }
        result[i][j] = sum;
      }
    }

    return result;
  }

  matrixDeterminant(matrix: number[][]): number {
    const n = matrix.length;
    
    if (n !== matrix[0].length) {
      throw new Error('Matrix must be square');
    }

    if (n === 1) return matrix[0][0];
    if (n === 2) return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];

    let det = 0;
    for (let i = 0; i < n; i++) {
      const subMatrix = matrix.slice(1).map(row => 
        row.filter((_, colIndex) => colIndex !== i)
      );
      det += Math.pow(-1, i) * matrix[0][i] * this.matrixDeterminant(subMatrix);
    }

    return det;
  }

  // Equation Solving
  solveLinear(a: number, b: number): number {
    // Solve ax + b = 0
    if (a === 0) {
      throw new Error('No solution (a = 0)');
    }
    return -b / a;
  }

  solveQuadratic(a: number, b: number, c: number): { real: number[]; complex: string[] } {
    const discriminant = b * b - 4 * a * c;
    
    if (discriminant > 0) {
      const x1 = (-b + Math.sqrt(discriminant)) / (2 * a);
      const x2 = (-b - Math.sqrt(discriminant)) / (2 * a);
      return { real: [x1, x2], complex: [] };
    } else if (discriminant === 0) {
      const x = -b / (2 * a);
      return { real: [x], complex: [] };
    } else {
      const realPart = -b / (2 * a);
      const imagPart = Math.sqrt(-discriminant) / (2 * a);
      return { 
        real: [], 
        complex: [
          `${realPart} + ${imagPart}i`,
          `${realPart} - ${imagPart}i`
        ]
      };
    }
  }

  // Utility Functions
  getGraphData(): GraphData[] {
    return this.graphData;
  }

  clearGraphs(): void {
    this.graphData = [];
  }

  factorial(n: number): number {
    if (n < 0) throw new Error('Factorial is not defined for negative numbers');
    if (n === 0 || n === 1) return 1;
    
    let result = 1;
    for (let i = 2; i <= n; i++) {
      result *= i;
    }
    return result;
  }

  fibonacci(n: number): number {
    if (n < 0) throw new Error('Fibonacci is not defined for negative numbers');
    if (n <= 1) return n;
    
    let a = 0, b = 1;
    for (let i = 2; i <= n; i++) {
      [a, b] = [b, a + b];
    }
    return b;
  }

  gcd(a: number, b: number): number {
    a = Math.abs(a);
    b = Math.abs(b);
    
    while (b !== 0) {
      [a, b] = [b, a % b];
    }
    return a;
  }

  lcm(a: number, b: number): number {
    return Math.abs(a * b) / this.gcd(a, b);
  }

  isPrime(n: number): boolean {
    if (n < 2) return false;
    if (n === 2) return true;
    if (n % 2 === 0) return false;
    
    for (let i = 3; i <= Math.sqrt(n); i += 2) {
      if (n % i === 0) return false;
    }
    return true;
  }
}

export const advancedMath = new AdvancedNumberScript();