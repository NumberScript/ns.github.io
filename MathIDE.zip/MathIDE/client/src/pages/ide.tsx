import { useState } from "react";
import { ActivityBar } from "@/components/ide/ActivityBar";
import { Sidebar } from "@/components/ide/Sidebar";
import { CodeEditor } from "@/components/ide/CodeEditor";
import { MathWorkPanel } from "@/components/ide/MathWorkPanel";
import { BottomPanel } from "@/components/ide/BottomPanel";
import { TabBar } from "@/components/ide/TabBar";
import { useIDEState } from "@/hooks/use-ide-state";

export default function IDE() {
  const {
    activePanel,
    setActivePanel,
    openFiles,
    activeFile,
    setActiveFile,
    showWork,
    setShowWork,
    mathWorkSteps,
    consoleOutput,
    addConsoleOutput,
    closeFile,
    createNewFile,
  } = useIDEState();

  const [showMathWork, setShowMathWork] = useState(true);
  const [showBottomPanel, setShowBottomPanel] = useState(true);

  return (
    <div className="h-screen bg-background text-foreground font-sans overflow-hidden">
      <div className="flex h-full">
        
        {/* Activity Bar */}
        <ActivityBar 
          activePanel={activePanel} 
          setActivePanel={setActivePanel}
          data-testid="activity-bar"
        />

        {/* Sidebar */}
        <Sidebar 
          activePanel={activePanel}
          openFiles={openFiles}
          activeFile={activeFile}
          setActiveFile={setActiveFile}
          createNewFile={createNewFile}
          data-testid="sidebar"
        />

        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col">
          
          {/* Tab Bar */}
          <TabBar
            openFiles={openFiles}
            activeFile={activeFile}
            setActiveFile={setActiveFile}
            closeFile={closeFile}
            showWork={showWork}
            setShowWork={setShowWork}
            data-testid="tab-bar"
          />

          {/* Editor and Right Panel */}
          <div className="flex flex-1">
            
            {/* Code Editor */}
            <CodeEditor
              file={activeFile}
              showWork={showWork}
              onContentChange={(content) => {
                if (activeFile) {
                  // Update file content
                  activeFile.content = content;
                }
              }}
              onOutput={addConsoleOutput}
              data-testid="code-editor"
            />

            {/* Math Work Panel */}
            {showWork && showMathWork && (
              <MathWorkPanel
                steps={mathWorkSteps}
                variables={activeFile?.variables || {}}
                onClose={() => setShowMathWork(false)}
                data-testid="math-work-panel"
              />
            )}

          </div>

          {/* Bottom Panel */}
          {showBottomPanel && (
            <BottomPanel
              consoleOutput={consoleOutput}
              onClose={() => setShowBottomPanel(false)}
              data-testid="bottom-panel"
            />
          )}

        </div>

      </div>
    </div>
  );
}
