import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time collaboration
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Track active collaborative sessions
  const collaborativeSessions = new Map<string, Set<WebSocket>>();
  const userCursors = new Map<WebSocket, { userId: string; fileId: string; position: number }>();

  wss.on('connection', (ws: WebSocket) => {
    console.log('New WebSocket connection established');

    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        switch (message.type) {
          case 'join-session':
            joinCollaborativeSession(ws, message.fileId, message.userId);
            break;
          
          case 'text-operation':
            handleTextOperation(ws, message);
            break;
          
          case 'cursor-update':
            handleCursorUpdate(ws, message);
            break;
          
          case 'leave-session':
            leaveCollaborativeSession(ws);
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      leaveCollaborativeSession(ws);
      userCursors.delete(ws);
    });

    // Send welcome message
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'connected', message: 'Connected to NumberScript collaboration server' }));
    }
  });

  function joinCollaborativeSession(ws: WebSocket, fileId: string, userId: string) {
    if (!collaborativeSessions.has(fileId)) {
      collaborativeSessions.set(fileId, new Set());
    }
    
    const session = collaborativeSessions.get(fileId)!;
    session.add(ws);
    
    // Notify other users in the session
    broadcastToSession(fileId, {
      type: 'user-joined',
      userId,
      timestamp: Date.now()
    }, ws);

    // Send current session info to the new user
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'session-joined',
        fileId,
        participants: Array.from(session).length
      }));
    }
  }

  function handleTextOperation(ws: WebSocket, message: any) {
    const { fileId, operation, userId } = message;
    
    // Apply operational transform logic here
    const transformedOperation = transformOperation(operation, fileId);
    
    // Broadcast to all other users in the session
    broadcastToSession(fileId, {
      type: 'text-operation',
      operation: transformedOperation,
      userId,
      timestamp: Date.now()
    }, ws);
  }

  function handleCursorUpdate(ws: WebSocket, message: any) {
    const { fileId, userId, position } = message;
    
    userCursors.set(ws, { userId, fileId, position });
    
    // Broadcast cursor position to other users
    broadcastToSession(fileId, {
      type: 'cursor-update',
      userId,
      position,
      timestamp: Date.now()
    }, ws);
  }

  function leaveCollaborativeSession(ws: WebSocket) {
    Array.from(collaborativeSessions.entries()).forEach(([fileId, session]) => {
      if (session.has(ws)) {
        session.delete(ws);
        
        // Notify others that user left
        const cursor = userCursors.get(ws);
        if (cursor) {
          broadcastToSession(fileId, {
            type: 'user-left',
            userId: cursor.userId,
            timestamp: Date.now()
          }, ws);
        }
        
        // Clean up empty sessions
        if (session.size === 0) {
          collaborativeSessions.delete(fileId);
        }
      }
    });
  }

  function broadcastToSession(fileId: string, message: any, excludeWs?: WebSocket) {
    const session = collaborativeSessions.get(fileId);
    if (!session) return;

    session.forEach(ws => {
      if (ws !== excludeWs && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
      }
    });
  }

  function transformOperation(operation: any, fileId: string): any {
    // Simple operational transform implementation
    // In a production system, this would be more sophisticated
    return {
      ...operation,
      transformed: true,
      timestamp: Date.now()
    };
  }

  return httpServer;
}
